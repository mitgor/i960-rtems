/home/mit/i960-callback-20261011-1jOTHm/module-release/dac960rtems.o
