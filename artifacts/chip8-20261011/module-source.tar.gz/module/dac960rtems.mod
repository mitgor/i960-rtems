/home/mit/i960-chip8-20261011-3W3aWm/module/dac960rtems.o
