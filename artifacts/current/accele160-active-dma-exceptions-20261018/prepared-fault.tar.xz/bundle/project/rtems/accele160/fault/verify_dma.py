#!/usr/bin/env python3
"""Replay an active-DMA terminal archive; never execute archived code."""
import argparse,hashlib,json,struct,tarfile
from host import validate
sha=lambda b:hashlib.sha256(b).hexdigest()
def verify(path):
    with tarfile.open(path) as t:
        files={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
    def read(n):return files[n]
    def obj(n):return json.loads(read(n))
    for n,h in obj('bundle/bundle.json')['files'].items():assert sha(read('bundle/'+n))==h,n
    result,=[n for n in files if n.endswith('/run/terminal/result.json')]
    terminal=result[:-11];session=terminal[:-13];r=obj(result);mode=r['mode'];nonce=r['nonce']
    assert mode in (6,7)
    ready=read(terminal+'ready.bin');validate(ready,nonce,mode,False)
    assert read(terminal+'stale.bin')[64:]==ready[64:]
    raw=read(terminal+'terminal.bin');w=validate(raw,nonce,mode,True)
    assert raw==read(terminal+'stable.bin')==read(terminal+'after-stop.bin')
    assert w[175]<10000000 and not w[186]&0x42d
    assert w[187:192]==(1,w[180]+32768,0,0,7)
    if mode==7:assert validate(read(terminal+'armed.bin'),nonce,mode,False)[155]==1
    expected=bytes((i^(i>>8)^0x69)&255 for i in range(65536))
    assert read(terminal+'source.bin')==expected
    for slot in (0,1):
        b=read(terminal+f'frame{slot}.bin');assert len(b)==77824
        assert b[:4096]==b'\xa5'*4096 and b[69664:]==b'\xa5'*8160
        assert b[4096:69632]==(expected if slot==0 else b'\x5a'*65536)
        assert b[69632:69664]==(struct.pack('<8I',*(0x444d4100+i for i in range(8))) if slot==0 else bytes(32))
    descriptors=read(terminal+'descriptors.bin');assert len(descriptors)==32800
    for i,d in enumerate(struct.iter_unpack('<8I',descriptors)):
        assert d==(w[180]+(i+1)*32 if i<1024 else 0,w[182]+(0 if i<1024 else 65536),0,
            w[181] if i<1024 else w[185],65536 if i<1024 else 32,7,0,0)
    assert obj(terminal+'release-denied.json')['returncode']!=0
    assert r['admission']['done']=='0' and r['admission']['released']=='0'
    assert r['pin']['retained']=='1' and r['pin']['guard_changes']=='0'
    assert int(r['pin']['bus0'],16)==w[182]
    assert all(r[k] for k in ('retained','active_dma_at_entry','drained_after_terminal',
        'dma_source_retained','dma_destination_retained','completion_not_synthesized'))
    symbols={a[2]:int(a[0],16) for line in read('bundle/kernel/kernel.symbols').decode().splitlines() if len(a:=line.split())==3}
    assert w[148]==symbols['_accele_fault_entry'] and w[149]==symbols['_accele_nmi_entry']
    if mode==6:assert w[164]==symbols['_accele_raise_fault']+4
    m=obj('bundle/project/rtems/accele160/doom_dma/persistent-manifest.json');assert m['terminal_test']==mode
    for n in ('kernel','image'):assert sha(read('bundle/kernel/'+n+'.bin'))==m[n+'_sha256']
    for n,h in m['terminal_sources'].items():assert sha(read('bundle/project/rtems/accele160/fault/'+n))==h
    assert sha(read('bundle/project/rtems/accele160/doom_dma/frame_dma.h'))==m['dma_source_sha256']
    boots=[]
    for i in (0,1):
        prefix=session+f'pre-{i}/'
        assert sha(read(prefix+'data.bin'))=='1c4995ada54f944265c11f346177708351b4ff5a1003ba232f7e39b6a74b89bd'
        s=dict(x.split('=') for x in read(prefix+'status.txt').decode().split())
        assert s['done']=='1' and all(s[k]=='0' for k in ('status','residual','guard_changes'))
        boots.append(obj(prefix+'request.json')['boot_id'])
    assert boots[0]==boots[1]==obj(session+'run/result.json')['boot_id']
    return dict(mode=mode,boot_id=boots[0],kernel_sha256=m['kernel_sha256'],paired_firmware=True,
        entry_csr=hex(w[176]),entry_next_descriptor=hex(w[178]),entry_byte_count=w[179],
        drain_polls=w[175],drain_csr=hex(w[186]),finite_bytes=1024*65536,
        fault_or_nmi_record=[hex(v) for v in w[161:165]],source_and_descriptors_unchanged=True,
        guards_intact=True,second_target_untouched=True,release_denied=True,retained=True,
        post_test_reset_verified=False)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('archive');a=p.parse_args()
    print(json.dumps(verify(a.archive),indent=2))
