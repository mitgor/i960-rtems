/home/mit/i960-accele160-doom-dma-20261017-module/dma_frames.o
