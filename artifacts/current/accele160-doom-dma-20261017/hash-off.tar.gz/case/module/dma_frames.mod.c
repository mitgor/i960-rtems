#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xa4290e5d, "pci_get_domain_bus_and_slot" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x1a18417e, "pci_dev_put" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x6e20af15, "try_module_get" },
	{ 0xfd710147, "pci_read_config_word" },
	{ 0x6b18d4d2, "dma_alloc_attrs" },
	{ 0xfb578fc5, "memset" },
	{ 0x67a9646, "debugfs_create_dir" },
	{ 0xb17d288, "debugfs_create_file" },
	{ 0x82eaa415, "__module_get" },
	{ 0xbf23f1f4, "module_put" },
	{ 0x7271639f, "dma_free_attrs" },
	{ 0xadd26b67, "debugfs_remove" },
	{ 0x482b4307, "default_llseek" },
	{ 0xfe899ab9, "simple_open" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x619cb7dd, "simple_read_from_buffer" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x96848186, "scnprintf" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x2f93810, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "79E44F14EA33935675891AD");
