# Read only the retained companion's owned allocation via /proc/kcore.
import os,struct,json,hashlib
from pathlib import Path
symbols={}
for line in Path('/proc/kallsyms').read_text().splitlines():
 fields=line.split()
 if len(fields)==4 and fields[3]=='[companion]' and fields[2] in ('allocation','length'):
  symbols[fields[2]]=int(fields[0],16)
assert set(symbols)=={'allocation','length'} and all(symbols.values())
fd=os.open('/proc/kcore',os.O_RDONLY)
h=os.pread(fd,64,0);assert h[:6]==b'\x7fELF\x02\x01'
phoff=struct.unpack_from('<Q',h,32)[0];entsize,num=struct.unpack_from('<HH',h,54)
segments=[]
for i in range(num):
 typ,flags,off,va,pa,fs,ms,align=struct.unpack('<IIQQQQQQ',os.pread(fd,56,phoff+i*entsize))
 if typ==1:segments.append((va,fs,off))
def read(va,n):
 for start,size,off in segments:
  if start<=va and va+n<=start+size:
   b=os.pread(fd,n,off+va-start);assert len(b)==n;return b
 raise ValueError('unmapped exact owned range')
pointer=struct.unpack('<Q',read(symbols['allocation'],8))[0]
length=struct.unpack('<I',read(symbols['length'],4))[0];assert length==164576
size=length+65536+1048576
out=Path('/home/mit/i960-accele160-20261016/retained-ezassist');out.mkdir(exist_ok=False)
for i in range(2):(out/f'allocation-{i}.bin').write_bytes(read(pointer,size))
(out/'metadata.json').write_text(json.dumps(dict(requested_length=length,prefix_guard=65536,suffix_guard=1048576,bytes=size,only_owned_dma_allocation=True),indent=2))
print(out)
