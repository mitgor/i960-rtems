#define I960_DOOM_DMA 1
#define I960_DOOM_OWNED 1
#define I960_DOOM_CHECKPOINTS 1
#define I960_DOOM_RUNTIME 1
#define I960_DOOM_ENGINE 1
#define I960_DOOM_PLAY 1
#define I960_LARGE_CONTROL 1
// SPDX-License-Identifier: GPL-2.0
/* Controlled PG experiments: Enquiry2, LoadImage, and opt-in fixed scratch upload.
 * No opcode 0x22, reset, maintenance mode, or arbitrary opcode interface.
 * Read direction recovered from vendor dataflow: see docs/firmware/VENDOR-READ-PATH.md.
 * Results/captures are exported via debugfs; captures are NOT validated dumps.
 * On uncertain completion, DMA allocation and module are retained until reboot.
 */
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/io.h>
#include <linux/iopoll.h>
#include <linux/dma-mapping.h>
#include <linux/debugfs.h>
#include <linux/slab.h>
#include <linux/delay.h>
#include <crypto/hash.h>
#include "stage_data.h"
#include "staging_pointer.h"
#include "ram_scratch.h"
#include <linux/firmware.h>
#include <linux/miscdevice.h>
#include <linux/mutex.h>
#include <linux/uaccess.h>
#include <linux/kref.h>
#include <linux/ktime.h>
#include "load_policy.h"
#include "buffer_io.h"
#include "rom_exec.h"

#define IDB 0x20
#define ODB 0x2c
#define IRQMASK 0x34
#define MBOX 0x1000
#define STATUS_ID 0x1018
#define STATUS 0x101a
#define DMA_SIZE 65536u
#define MAX_READ 0xf000u
/* PG 512 KiB profile: bootstrap C000C600, source FEF80000.
 * Fresh live capture places BIOS at 0x28000 and firmware at 0x30000.
 * See docs/firmware/SNAPSHOT-RECOVERY.md; coverage still requires image validation. */
#define IMAGE_WINDOW 0x80000u
#define WAIT_US 2000000u

static char *bdf = "0000:37:09.1";
static bool attempt;
static bool pointer_check;
static bool runtime_check;
static bool scratch_check;
static bool dram_hook_check;
static bool rom_table_check;
static bool rom_exec_check;
static char *firmware_name;
static unsigned int payload_argument;
static unsigned int entry_offset;
static bool buffer_io;
module_param(buffer_io, bool, 0444);
module_param(firmware_name, charp, 0444);
module_param(payload_argument, uint, 0444);
module_param(entry_offset, uint, 0444);
static bool stage_check;
module_param(stage_check, bool, 0444);
MODULE_PARM_DESC(stage_check, "Full paired staging read, three pinned RAM patches, full verification and restoration; no programming");
static bool flash_map_check;
module_param(flash_map_check, bool, 0444);
MODULE_PARM_DESC(flash_map_check, "Read-only exact FEFB0200/FEFC8200/FEFE0000 live mapping comparison");
module_param(rom_exec_check, bool, 0444);
MODULE_PARM_DESC(rom_exec_check, "Fixed reversible RAM dispatch + physically mapped flash RET probe");
module_param(rom_table_check, bool, 0444);
MODULE_PARM_DESC(rom_table_check, "Fixed read-only opcode-0x6f dispatch-word observation");
module_param(dram_hook_check, bool, 0444);
MODULE_PARM_DESC(dram_hook_check, "Fixed read-only 64-byte C0120000 hook-site observation");
module_param(scratch_check, bool, 0444);
MODULE_PARM_DESC(scratch_check, "Fixed 16-byte RAM scratch write/read/restore after runtime checks");
module_param(runtime_check, bool, 0444);
module_param(pointer_check, bool, 0444);
MODULE_PARM_DESC(pointer_check, "Fixed four-byte staging pointer verification; no arbitrary offsets");
static unsigned int length = 512;
static unsigned int flash_offset;
module_param(bdf, charp, 0444);
module_param(attempt, bool, 0444);
module_param(length, uint, 0444);
module_param(flash_offset, uint, 0444);
MODULE_PARM_DESC(attempt, "Attempt two bounded LoadImage reads; see docs/firmware/VENDOR-READ-PATH.md");

struct capture {
    struct debugfs_blob_wrapper blob;
    u8 *data;
};
struct experiment {
    struct kref refs;
    struct mutex session_lock;
    struct miscdevice misc;
    bool owned, removed, ready, runner_uncertain, response_ready, misc_registered;
    u32 sequence, steps, output_length;
    bool output_valid, irq_may_run,mu_used,mu_failed,mu_halted,mu_resident;unsigned int monitor_epoch;
    const struct firmware *payload;
    bool load_armed;
    u8 runner_code[EXEC_FLASH_SIZE];
    struct pci_dev *pdev;
    void __iomem *bar;
    void *dma_buf;void *wr_buf[2];dma_addr_t wr_bus[2];unsigned wr_next[2],wr_total;void *pp_buf[2];dma_addr_t pp_bus[2];unsigned pp_next[2],pp_reads[2][3];bool pp_enabled,pp_running;void *wad_dma_buf;dma_addr_t wad_dma_bus;unsigned wad_dma_gen,wad_dma_geometry[3];bool wad_dma_pending;void *frame_dma_buf;dma_addr_t frame_dma_bus;struct debugfs_blob_wrapper frame_dma_blob;unsigned frame_dma_gen,frame_dma_no_crc;bool frame_dma_pending,frame_dma_valid;unsigned frame_dma_fault[100];struct debugfs_blob_wrapper frame_dma_fault_blob;
    dma_addr_t dma;
    u32 saved_irq;
    u16 saved_command;
    bool stage_armed, stage_dirty;
    bool pending, pinned, pointer_armed, pointer_verified, runtime_verified, scratch_armed, scratch_dirty, dram_hook_armed, rom_table_armed, flash_map_armed, exec_armed, exec_dirty;
    const u8 *upload_data;
    u16 exec_expected_status;
    u16 exec_last_status;
    u32 audit_address, audit_length;
    u8 tag;
    struct dentry *directory;
    struct capture capture[54];
    struct capture stage[8];
    char result[65536];
    struct debugfs_blob_wrapper result_blob;
    size_t used;
};

#define record(d, fmt, ...) do { \
    (d)->used += scnprintf((d)->result + (d)->used, \
        sizeof((d)->result) - (d)->used, fmt, ##__VA_ARGS__); \
    dev_info(&(d)->pdev->dev, fmt, ##__VA_ARGS__); \
} while (0)

static unsigned int changed(const u8 *p, size_t n, u8 pattern)
{
    unsigned int count = 0;
    while (n--) if (*p++ != pattern) count++;
    return count;
}

static int issue(struct experiment *d, u8 opcode, u16 count, u32 offset,
                 u8 pattern, unsigned int slot)
{
    u32 input, output, words[3];
    u16 status, returned;
    int rc;
    unsigned int changes, guard;
    if (d->pending) return -EPERM;
    if (opcode != 0x1c && opcode != 0x20 && opcode != 0x21 && opcode != 0x6f) return -EPERM;
    if (opcode == 0x6f && (!d->exec_armed || !d->exec_dirty || count || offset)) return -EPERM;
    if (opcode == 0x21 && (!d->upload_data ||
        (!scratch_allowed(opcode,count,offset,d->runtime_verified,d->scratch_armed) &&
         !exec_upload_allowed(count,offset,d->runtime_verified,d->exec_armed) &&
         !load_upload_allowed(count,offset,d->payload->size,d->runtime_verified,d->load_armed)))) return -EPERM;
    if (opcode == 0x20 && !sp_allowed(count, offset, d->pointer_armed) &&
        !(runtime_check && sp_runtime_allowed(count, offset, d->pointer_verified) &&
          d->audit_length && count == d->audit_length &&
          offset == d->audit_address - STAGING_BASE) &&
        !sp_dram_hook_allowed(count, offset, d->runtime_verified, d->dram_hook_armed) &&
        !sp_rom_table_allowed(count, offset, d->runtime_verified, d->rom_table_armed) &&
        !(d->runtime_verified && d->flash_map_armed && count == 64 &&
          (offset == 0xfefb0200u - STAGING_BASE ||
           offset == 0xfefc8200u - STAGING_BASE ||
           offset == 0xfefe0000u - STAGING_BASE)) &&
        !exec_read_allowed(count, offset, d->runtime_verified, d->exec_armed) &&
        !scratch_allowed(opcode,count,offset,d->runtime_verified,d->scratch_armed)) return -EPERM;
    /* Unknown stale completions are refused, not attributed to this command. */
    output = readl(d->bar + ODB);
    if (output & 1) {
        record(d, "refused stale completion: ODB=%08x id=%04x status=%04x\n",
               output, readw(d->bar + STATUS_ID), readw(d->bar + STATUS));
        return -EBUSY;
    }
    rc = readl_poll_timeout(d->bar + IDB, input, !(input & 3), 50, WAIT_US);
    if (rc) { record(d, "refused busy/init input: IDB=%08x\n", input); return rc; }
    d->tag++;
    memset(d->dma_buf, pattern, DMA_SIZE);
    if (opcode == 0x21) memcpy(d->dma_buf, d->upload_data, count);
    words[0] = opcode | ((u32)d->tag << 8) | ((u32)count << 16);
    words[1] = offset;
    words[2] = lower_32_bits(d->dma);
    record(d, "submit op=%02x id=%u len=%u offset=%08x dma=%08x pattern=%02x mailbox=%08x,%08x,%08x,00\n",
           opcode, d->tag, count, offset, words[2], pattern, words[0], words[1], words[2]);
    writel(words[0], d->bar + MBOX);
    writel(words[1], d->bar + MBOX + 4);
    writel(words[2], d->bar + MBOX + 8);
    writeb(0, d->bar + MBOX + 12);
    dma_wmb();
    d->pending = true;
    writel(1, d->bar + IDB);
    rc = readl_poll_timeout(d->bar + ODB, output, output & 1, 50, WAIT_US);
    if (rc) {
        record(d, "uncertain completion: timeout ODB=%08x IDB=%08x; retaining DMA/module\n",
               output, readl(d->bar + IDB));
        return rc;
    }
    returned = readw(d->bar + STATUS_ID);
    status = readw(d->bar + STATUS);
    if ((returned & 0xff) != d->tag) {
        record(d, "uncertain completion: expected-id=%u observed-id=%04x status=%04x; retaining DMA/module\n",
               d->tag, returned, status);
        return -EPROTO;
    }
    dma_rmb();
    /* PG status consumption sequence, with 32-bit doorbell accesses. */
    writel(1, d->bar + ODB);
    writel(2, d->bar + IDB);
    readl(d->bar + IDB); /* flush posted acknowledgments */
    d->pending = false;
    changes = changed(d->dma_buf, opcode == 0x1c ? 512 : count, pattern);
    guard = changed((u8 *)d->dma_buf + (opcode == 0x1c ? 512 : count),
                    DMA_SIZE - (opcode == 0x1c ? 512 : count), pattern);
    record(d, "complete op=%02x id=%04x status=%04x changed=%u guard-changed=%u head=%*ph\n",
           opcode, returned, status, changes, guard, 16, d->dma_buf);
    /* ARRAY_SIZE is a deliberate no-small-capture slot for full-image reads. */
    if (slot < ARRAY_SIZE(d->capture))
        memcpy(d->capture[slot].data, d->dma_buf, d->capture[slot].blob.size);
    if (guard) return -EOVERFLOW;
    if (opcode == 0x6f) {
        d->exec_last_status = status;
        if (d->exec_expected_status == 0xffff)
            return (status == 0x0104 || status == 0x017d || status == 0x017e || status == 0x017f) ? 0 : -EIO;
        return status == d->exec_expected_status ? 0 : -EIO;
    }
    if (status) return -EIO;
    if (opcode == 0x1c) {
        const u8 *b = d->dma_buf;
        if (!changes || b[4] != 4 || b[5] != 7) {
            record(d, "Enquiry2 did not validate as firmware 4.07; refusing image read\n");
            return -ENODATA;
        }
    }
    return 0;
}

static int run_pointer(struct experiment *d)
{
    static const u8 prefix[16] = {0x50,0x4b,3,4,0x0a,0,0,0,6,0,0xf4,0x9d,0x82,0x27,0x90,0x2a};
    int rc;
    if (!sp_profile(d->capture[0].data)) return -EINVAL;
    rc = issue(d, 0x20, 512, 0, 0xa5, 4);
    if (rc) return rc;
    rc = issue(d, 0x20, 512, 0, 0x5a, 5);
    if (rc) return rc;
    if (memcmp(d->capture[4].data, prefix, sizeof(prefix)) ||
        memcmp(d->capture[4].data, d->capture[5].data, 512)) return -ENODATA;
    d->pointer_armed = true;
    rc = issue(d, 0x20, 4, POINTER_OFFSET, 0xa5, 1);
    if (rc) goto disarm;
    if (sp_word(d->capture[1].data) != STAGING_BASE) { rc = -ENODATA; goto disarm; }
    rc = issue(d, 0x20, 4, POINTER_OFFSET, 0x5a, 2);
    if (rc) goto disarm;
    if (sp_word(d->capture[2].data) != STAGING_BASE) { rc = -ENODATA; goto disarm; }
    d->pointer_armed = false;
    rc = issue(d, 0x1c, 0, 0, 0x5a, 3);
    if (!rc && !sp_profile(d->capture[3].data)) rc = -ENODATA;
    if (!rc) d->pointer_verified = true;
    if (!rc) record(d, "VERIFIED staging pointer=%08x at local=c0112a70\n", STAGING_BASE);
 disarm:
    d->pointer_armed = false;
    return rc;
}

static int read_pair(struct experiment *d, u32 address, u16 count, unsigned int slot)
{
    int rc;
    d->audit_address = address;
    d->audit_length = count;
    rc = issue(d, 0x20, count, address - STAGING_BASE, 0xa5, slot);
    if (!rc) rc = issue(d, 0x20, count, address - STAGING_BASE, 0x5a, slot+1);
    d->audit_length = 0;
    if (!rc && memcmp(d->capture[slot].data, d->capture[slot+1].data, count)) rc = -ENODATA;
    return rc;
}

static int run_runtime(struct experiment *d)
{
    static const u8 code[16] = {0x06,0x1e,0x80,0x5c,0x5c,0x27,0,9,0,0x30,0xf0,0x82,0x98,0x5d,0x0a,0xc0};
    u32 board, alias;
    int rc = read_pair(d, 0xc004a2e0, 16, 6);
    if (rc) return rc;
    if (memcmp(code, d->capture[6].data, 16)) return -ENODATA;
    rc = read_pair(d, 0xc011e22c, 8, 8);
    if (rc) return rc;
    board = sp_word(d->capture[8].data);
    alias = sp_word(d->capture[8].data+4);
    record(d, "runtime board=%08x alias=%08x\n", board, alias);
    if (board != 0xc0110780 || alias != 0xc1000000) return -ERANGE;
    rc = read_pair(d, board, 512, 10);
    if (rc) return rc;
    record(d, "runtime callbacks read=%08x write=%08x program=%08x\n",
           sp_word(d->capture[10].data+0xe0), sp_word(d->capture[10].data+0xe4),
           sp_word(d->capture[10].data+0xec));
    if (sp_word(d->capture[10].data+0xe0)!=0xc004ce90 ||
        sp_word(d->capture[10].data+0xe4)!=0xc004ced0 ||
        sp_word(d->capture[10].data+0xec)!=0xc004cf80) return -ENODATA;
    rc = issue(d, 0x1c, 0, 0, 0x5a, 3);
    if (!rc && !sp_profile(d->capture[3].data)) rc = -ENODATA;
    if (!rc) d->runtime_verified = true;
    return rc;
}

static int run_scratch(struct experiment *d)
{
    int rc, first_rc, restore_rc;
    if (!d->runtime_verified) return -EPERM;
    d->scratch_armed = true;
    rc = read_pair(d, STAGING_BASE + SCRATCH_REGION_OFFSET, SCRATCH_REGION_SIZE, 12);
    if (rc) goto done;
    if (scratch_matches(d->capture[12].data,d->capture[12].data,scratch_pattern)) {
        rc = -ENODATA; goto done; /* An already matching region cannot prove the write. */
    }
    d->upload_data = scratch_pattern;
    d->scratch_dirty = true; /* Conservative even if the submission later fails. */
    first_rc = issue(d, 0x21, SCRATCH_WRITE_SIZE, SCRATCH_WRITE_OFFSET, 0xa5, 18);
    if (d->pending) { rc = first_rc; goto done; }
    if (!first_rc) {
        first_rc = read_pair(d, STAGING_BASE+SCRATCH_REGION_OFFSET, SCRATCH_REGION_SIZE, 14);
        if (!first_rc && !scratch_matches(d->capture[12].data,d->capture[14].data,scratch_pattern))
            first_rc = -ENODATA;
    }
    if (d->pending) { rc = first_rc; goto done; }
    /* Restore after every known-complete write attempt, including failed validation. */
    d->upload_data = d->capture[12].data + 16;
    restore_rc = issue(d, 0x21, SCRATCH_WRITE_SIZE, SCRATCH_WRITE_OFFSET, 0x5a, 19);
    if (!restore_rc) restore_rc = read_pair(d, STAGING_BASE+SCRATCH_REGION_OFFSET, SCRATCH_REGION_SIZE, 16);
    if (!restore_rc && memcmp(d->capture[12].data,d->capture[16].data,SCRATCH_REGION_SIZE))
        restore_rc = -ENODATA;
    if (!restore_rc) {
        d->scratch_dirty = false;
        record(d, "RESTORED scratch region original 64 bytes\n");
    }
    rc = restore_rc ? restore_rc : first_rc;
    if (!rc) {
        rc = issue(d, 0x1c, 0, 0, 0x5a, 3);
        if (!rc && !sp_profile(d->capture[3].data)) rc = -ENODATA;
        if (!rc) record(d, "VERIFIED RAM scratch write/readback/restore local=c0fac010 length=16\n");
    }
 done:
    d->scratch_armed = false;
    d->upload_data = NULL;
    return rc;
}

static int run_dram_hook(struct experiment *d)
{
    int rc;
    if (!d->runtime_verified) return -EPERM;
    d->dram_hook_armed = true;
    rc = read_pair(d, DRAM_HOOK_ADDRESS, DRAM_HOOK_SIZE, 20);
    d->dram_hook_armed = false;
    if (!rc) record(d, "OBSERVED hook-site local=c0120000 length=64; occupancy is not ownership\n");
    return rc;
}

static int run_rom_table(struct experiment *d)
{
    int rc;
    if (!d->runtime_verified) return -EPERM;
    d->rom_table_armed = true;
    rc = read_pair(d, ROM_TABLE_ADDRESS, 4, 22);
    d->rom_table_armed = false;
    if (!rc && sp_word(d->capture[22].data) != 0xc001fe98u) rc = -ENODATA;
    if (!rc) record(d, "VERIFIED stock opcode-6f table word local=c001f9bc value=c001fe98; fetch/cache untested\n");
    return rc;
}

static int run_flash_map(struct experiment *d)
{
    int rc;
    if (!d->runtime_verified) return -EPERM;
    d->flash_map_armed = true;
    rc = read_pair(d, 0xfefb0200u, 64, 24);
    if (!rc) rc = read_pair(d, 0xfefc8200u, 64, 26);
    if (!rc) rc = read_pair(d, 0xfefe0000u, 64, 28);
    d->flash_map_armed = false;
    if (!rc) record(d, "OBSERVED paired live FEFB0200/FEFC8200/FEFE0000 windows; inspect captures against pinned image; instruction fetch untested\n");
    return rc;
}

static int exec_upload(struct experiment *d, const u8 *data, u16 count,
                       u32 offset, unsigned int slot)
{
    int rc;
    d->upload_data = data;
    rc = issue(d, 0x21, count, offset, 0xa5, slot);
    d->upload_data = NULL;
    return rc;
}

static int exec_region_matches(const u8 *before, const u8 *after,
                               const u8 *code, size_t code_size)
{
    return !memcmp(after, code, code_size) &&
           !memcmp(after + code_size, before + code_size,
                   EXEC_REGION_SIZE - code_size);
}

static int run_rom_exec(struct experiment *d)
{
    int rc = 0, test_rc = 0, restore_rc = 0, step;
    bool ram_attempted = false, flash_attempted = false, table_attempted = false;
    if (!d->runtime_verified) return -EPERM;
    d->exec_armed = true;
    rc = read_pair(d, EXEC_TABLE_ADDRESS, 4, 22);
    if (rc) goto done;
    if (sp_word(d->capture[22].data) != 0xc001fe98u) { rc = -ENODATA; goto done; }
    rc = read_pair(d, EXEC_RAM_ADDRESS, EXEC_REGION_SIZE, 24);
    if (rc) goto done;
    rc = read_pair(d, EXEC_FLASH_ADDRESS, EXEC_REGION_SIZE, 26);
    if (rc) goto done;
    if (!memcmp(d->capture[24].data, exec_ram_code, EXEC_RAM_SIZE) ||
        !memcmp(d->capture[26].data, exec_flash_code, EXEC_FLASH_SIZE)) {
        rc = -ENODATA; goto done;
    }

    d->exec_dirty = true; /* Conservative from the first possible RAM write. */
    ram_attempted = true;
    test_rc = exec_upload(d, exec_ram_code, EXEC_RAM_SIZE, EXEC_RAM_OFFSET, 28);
    if (d->pending || test_rc) goto restore;
    test_rc = read_pair(d, EXEC_RAM_ADDRESS, EXEC_REGION_SIZE, 29);
    if (test_rc || !exec_region_matches(d->capture[24].data, d->capture[29].data,
                                        exec_ram_code, EXEC_RAM_SIZE)) {
        if (!test_rc) test_rc = -ENODATA;
        goto restore;
    }
    table_attempted = true;
    test_rc = exec_upload(d, exec_ram_pointer, 4, EXEC_TABLE_OFFSET, 31);
    if (d->pending || test_rc) goto restore;
    test_rc = read_pair(d, EXEC_TABLE_ADDRESS, 4, 32);
    if (test_rc || sp_word(d->capture[32].data) != EXEC_RAM_ADDRESS) {
        if (!test_rc) test_rc = -ENODATA;
        goto restore;
    }
    d->exec_expected_status = 0x017e;
    test_rc = issue(d, 0x6f, 0, 0, 0xa5, 34);
    if (d->pending || test_rc) goto restore;
    record(d, "VERIFIED changed RAM dispatch word executed returning RAM stub status=017e\n");

    flash_attempted = true;
    test_rc = exec_upload(d, exec_flash_code, EXEC_FLASH_SIZE, EXEC_FLASH_OFFSET, 35);
    if (d->pending || test_rc) goto restore;
    test_rc = read_pair(d, EXEC_FLASH_ADDRESS, EXEC_REGION_SIZE, 36);
    if (test_rc || !exec_region_matches(d->capture[26].data, d->capture[36].data,
                                        exec_flash_code, EXEC_FLASH_SIZE)) {
        if (!test_rc) test_rc = -ENODATA;
        goto restore;
    }
    test_rc = exec_upload(d, exec_flash_pointer, 4, EXEC_TABLE_OFFSET, 38);
    if (d->pending || test_rc) goto restore;
    test_rc = read_pair(d, EXEC_TABLE_ADDRESS, 4, 39);
    if (test_rc || sp_word(d->capture[39].data) != EXEC_FLASH_ADDRESS) {
        if (!test_rc) test_rc = -ENODATA;
        goto restore;
    }
    d->exec_expected_status = 0xffff;
    test_rc = issue(d, 0x6f, 0, 0, 0x5a, 41);
    if (d->pending || test_rc) goto restore;
    if (d->exec_last_status == 0x017e) {
        d->exec_expected_status = 0x017f;
        test_rc = issue(d, 0x6f, 0, 0, 0xa5, 52);
        if (d->pending || test_rc) goto restore;
    } else if (d->exec_last_status != 0x017f) {
        test_rc = -ENODATA;
        goto restore;
    }
    record(d, "VERIFIED post-startup callx to mapped stock flash RET returned status=017f\n");

restore:
    if (d->pending) { rc = test_rc; goto done; }
    /* Restore dispatch before changing either code site. Try every restoration
     * after a known-complete failure; retain the module if any check fails. */
    if (table_attempted) {
        step = exec_upload(d, d->capture[22].data, 4, EXEC_TABLE_OFFSET, 42);
        if (d->pending) { rc = test_rc ? test_rc : step; goto done; }
        step = read_pair(d, EXEC_TABLE_ADDRESS, 4, 43);
        if (!step && memcmp(d->capture[22].data, d->capture[43].data, 4)) step = -ENODATA;
        if (step) { restore_rc = step; rc = test_rc ? test_rc : restore_rc; goto done; }
        d->exec_expected_status = 0xffff;
        step = issue(d, 0x6f, 0, 0, 0xa5, 51);
        if (step) { restore_rc = step; rc = test_rc ? test_rc : restore_rc; goto done; }
        if (d->exec_last_status != 0x0104) {
            d->exec_expected_status = 0x0104;
            step = issue(d, 0x6f, 0, 0, 0x5a, 53);
            if (step) { restore_rc = step; rc = test_rc ? test_rc : restore_rc; goto done; }
        }
        record(d, "VERIFIED restored stock dispatch status=0104 before clearing RAM stubs\n");
    }
    if (ram_attempted) {
        step = exec_upload(d, d->capture[24].data, EXEC_RAM_SIZE, EXEC_RAM_OFFSET, 45);
        if (d->pending) { rc = test_rc ? test_rc : step; goto done; }
        step = read_pair(d, EXEC_RAM_ADDRESS, EXEC_REGION_SIZE, 46);
        if (!step && memcmp(d->capture[24].data, d->capture[46].data, EXEC_REGION_SIZE)) step = -ENODATA;
        if (step && !restore_rc) restore_rc = step;
    }
    if (d->pending) { rc = test_rc ? test_rc : restore_rc; goto done; }
    if (flash_attempted) {
        step = exec_upload(d, d->capture[26].data, EXEC_FLASH_SIZE, EXEC_FLASH_OFFSET, 48);
        if (d->pending) { rc = test_rc ? test_rc : step; goto done; }
        step = read_pair(d, EXEC_FLASH_ADDRESS, EXEC_REGION_SIZE, 49);
        if (!step && memcmp(d->capture[26].data, d->capture[49].data, EXEC_REGION_SIZE)) step = -ENODATA;
        if (step && !restore_rc) restore_rc = step;
    }
    if (!restore_rc) {
        d->exec_dirty = false;
        record(d, "RESTORED dispatch and both RAM sites to their original bytes\n");
    }
    rc = restore_rc ? restore_rc : test_rc;
    if (!d->pending) {
        step = issue(d, 0x1c, 0, 0, 0x5a, 3);
        if (!step && !sp_profile(d->capture[3].data)) step = -ENODATA;
        if (!rc) rc = step;
    }
done:
    d->exec_armed = false;
    d->upload_data = NULL;
    return rc;
}

#include "stage_rehearsal.h"

static int run(struct experiment *d)
{
    int rc, image_rc = 0, post_rc;
    rc = issue(d, 0x1c, 0, 0, 0xa5, 0);
    if (rc) return rc;
    if (pointer_check) {
        rc = run_pointer(d);
        if (!rc && runtime_check) rc = run_runtime(d);
        if (!rc && dram_hook_check) rc = run_dram_hook(d);
        if (!rc && rom_table_check) rc = run_rom_table(d);
        if (!rc && flash_map_check) rc = run_flash_map(d);
        if (!rc && rom_exec_check) rc = run_rom_exec(d);
        if (!rc && scratch_check) rc = run_scratch(d);
        if (!rc && stage_check) rc = run_stage(d);
        return rc;
    }
    if (!attempt) return rc;
    image_rc = issue(d, 0x20, length, flash_offset, 0xa5, 1);
    if (d->pending) return image_rc;
    if (!image_rc) image_rc = issue(d, 0x20, length, flash_offset, 0x5a, 2);
    if (d->pending) return image_rc;
    post_rc = issue(d, 0x1c, 0, 0, 0x5a, 3);
    if (post_rc) return post_rc;
    if (image_rc) return image_rc;
    if (memcmp(d->capture[1].data, d->capture[2].data, length)) {
        record(d, "NO VERIFIED TRANSFER: captures differ with sentinel pattern\n");
        return -ENODATA;
    }
    record(d, "candidate read: repeated captures match; still requires image/coverage validation\n");
    return 0;
}

static const struct pci_device_id ids[] = {
    { PCI_DEVICE(0x1069, 0x0010) }, { }
};
MODULE_DEVICE_TABLE(pci, ids);

static void free_captures(struct experiment *d)
{
    unsigned int i;
    for (i = 0; i < 54; i++) kfree(d->capture[i].data);
    for (i = 0; i < ARRAY_SIZE(d->stage); i++) kvfree(d->stage[i].data);
}

/* A file reference owns the session. Synchronous operations serialize with
 * release/remove; file_operations.owner holds the module through final close.
 * An uncertain transaction additionally pins module/DMA until reboot. */
static void session_free(struct kref *ref)
{
    struct experiment *d=container_of(ref,struct experiment,refs);
    free_captures(d);release_firmware(d->payload);kfree(d);
}
static void session_pin(struct experiment *d)
{
    if(!d->pinned && (d->pending || d->exec_dirty || d->stage_dirty)) {
        __module_get(THIS_MODULE);pci_dev_get(d->pdev);d->pinned=true;
        record(d,"SESSION FAILED: retained DMA/module; reboot required\n");
    }
}
static void session_log_start(struct experiment *d)
{ d->used=0;d->result[0]=0; }
static void session_log_end(struct experiment *d)
{ d->result_blob.size=d->used; }
static int session_file_open(struct inode *inode,struct file *file)
{
    struct miscdevice *misc=file->private_data;
    struct experiment *d=container_of(misc,struct experiment,misc);
    int rc;
    mutex_lock(&d->session_lock);
    if(d->owned || d->removed || d->pinned) {rc=-EBUSY;goto out;}
    session_log_start(d);d->sequence=0;d->response_ready=false;
    rc=session_open(d);
    if(rc) {session_close(d);session_pin(d);}
    else {kref_get(&d->refs);d->owned=true;file->private_data=d;}
    session_log_end(d);
out:
    mutex_unlock(&d->session_lock);return rc;
}
static ssize_t session_file_write(struct file *file,const char __user *buf,size_t count,loff_t *pos)
{
    struct experiment *d=file->private_data;u8 *request;int rc;
    if(count!=BIO_SIZE) return -EINVAL;
    request=memdup_user(buf,count);if(IS_ERR(request)) return PTR_ERR(request);
    mutex_lock(&d->session_lock);
    if(d->removed || !d->ready || d->pinned) {rc=-EIO;goto out;}
    if(d->response_ready) {rc=-EBUSY;goto out;}
    if(!bio_request_valid(request) || bio_word(request+8)<=d->sequence) {rc=-EINVAL;goto out;}
    session_log_start(d);rc=session_step(d,request);
    if(rc) {d->ready=false;session_close(d);session_pin(d);}
    else {
        d->response_ready=true;
        d->stage[6].blob.size=d->output_length;d->stage[7].blob.size=d->output_length;
    }
    session_log_end(d);
out:
    mutex_unlock(&d->session_lock);kfree(request);return rc?rc:count;
}
static ssize_t session_file_read(struct file *file,char __user *buf,size_t count,loff_t *pos)
{
    struct experiment *d=file->private_data;int rc;
    if(count!=BIO_SIZE) return -EINVAL;
    mutex_lock(&d->session_lock);
    if(d->removed || d->pinned) rc=-EIO;
    else if(!d->response_ready) rc=-EAGAIN;
    else if(copy_to_user(buf,d->stage[6].data+BIO_OFFSET,BIO_SIZE)) rc=-EFAULT;
    else {d->response_ready=false;rc=BIO_SIZE;}
    mutex_unlock(&d->session_lock);return rc;
}
static int session_file_release(struct inode *inode,struct file *file)
{
    struct experiment *d=file->private_data;int rc=0;
    mutex_lock(&d->session_lock);
    if(!d->removed && !d->pinned) {
        session_log_start(d);rc=session_close(d);session_pin(d);session_log_end(d);
    }
    d->owned=false;
    mutex_unlock(&d->session_lock);
    kref_put(&d->refs,session_free);
    return rc;
}
/* Serialized while no firmware command/callback is pending. The only device
 * writes here are the documented message-1 word. Never DMA/SCSI/config writes. */
static int monitor_wait(struct experiment*d,unsigned int expected,unsigned int alternative,unsigned int*seen){unsigned int i;
#ifdef I960_LARGE_CONTROL
 unsigned long deadline=jiffies+msecs_to_jiffies((expected&0xff000000u)==0x8b000000u?180000:20000);
 for(i=0;time_before(jiffies,deadline);i++){
#else
 for(i=0;i<15000;i++){
#endif
  if(readl(d->bar+ODB)&1)return -EPROTO;
  if(readl(d->bar+0x28)!=0x1fb||readl(d->bar+0x34)!=0xff)return -EIO;
  *seen=readl(d->bar+0x1c);if((*seen==expected||*seen==alternative)&&(!d->mu_resident||readl(d->bar+0x14)==0))return 0;
#ifdef I960_LARGE_CONTROL
  if((expected&0xff000000u)>=0x92000000u)usleep_range(50,100);else usleep_range(1000,1500);
#else
  usleep_range(1000,1500);
#endif
 }return -ETIMEDOUT;
}
static long monitor_ioctl(struct file*file,unsigned int cmd,unsigned long arg){struct experiment*d=file->private_data;unsigned int w[8],epoch,seen=0;int rc=0;
 if(cmd!=0xc0204d04u)return -ENOTTY;
 if(copy_from_user(w,(void __user*)arg,sizeof(w)))return -EFAULT;
 if(w[0]>7||!w[1]||w[1]>65535||w[2]>(w[0]==5?63:20)||w[3]||w[4]||w[5]||w[6]||w[7])return -EINVAL;
 if(w[0]==7&&w[2]>3)return -EINVAL;epoch=w[1];mutex_lock(&d->session_lock);
 if(d->removed||d->pinned||!d->owned||(!d->ready&&!d->mu_resident)||d->pending||d->runner_uncertain||!d->irq_may_run||d->response_ready||d->steps!=1||d->sequence!=1||d->mu_failed||d->mu_halted){rc=-EBUSY;goto out;}
 if(epoch!=d->monitor_epoch){rc=-ESTALE;goto out;}
 if((d->mu_resident&&w[0]<5)||(!d->mu_resident&&w[0]>=5)){rc=-EBUSY;goto out;}
 d->mu_used=true;w[3]=d->sequence;w[4]=readl(d->bar+ODB);w[6]=d->pending;w[7]=d->runner_uncertain;
 if(w[4]&1){rc=-EPROTO;goto failed;}
 record(d,"MONITOR enter action=%u sequence=%u pending=%u uncertain=%u completion=%u\n",w[0],w[3],w[6],w[7],w[4]&1);
 if(w[0]>=4){
  unsigned int token,reply;
  if(w[0]==4){d->mu_resident=true;d->ready=false;token=0x8a000000u;reply=0x8b000000u;}
  else if(w[0]==5){token=0x91000000u|(w[2]<<16);reply=0x92000000u|(w[2]<<16);}
  else if(w[0]==6){token=0x93000000u;reply=0x94000000u;}
  else{token=w[2]==3?0x9a000000u:w[2]==2?0x98000000u:w[2]?0x96000000u:0x90000000u;reply=w[2]==3?0x9b000000u:w[2]==2?0x99000000u:w[2]?0x97000000u:0x95000000u;}
  writel(token|epoch,d->bar+0x14);readl(d->bar+0x14);
  rc=monitor_wait(d,reply|epoch,reply|epoch,&seen);w[5]=seen;if(rc)goto failed;
  if(w[0]==5)w[2]=readl(d->bar+0x18);
  record(d,"EXCLUSIVE resident action=%u sequence=%u pending=0 uncertain=0 token=%08x value=%08x\n",w[0],d->sequence,seen,w[2]);goto copy;
 }
 writel((w[0]==1?0x84000000u:w[0]==3?0x88000000u:0x81000000u)|epoch,d->bar+0x14);readl(d->bar+0x14);
 if(w[0]==1)rc=monitor_wait(d,0x85000000u|epoch,0x85000000u|epoch,&seen);
 else if(w[0]==3){rc=monitor_wait(d,0x89000000u|epoch,0x89000000u|epoch,&seen);if(!rc)d->mu_halted=true;}
 else{
  rc=monitor_wait(d,0x82000000u|epoch,0x82000000u|epoch,&seen);if(rc)goto failed;
  record(d,"MONITOR parked original IRQ frame; no firmware callback pending\n");
  if(!w[0]){msleep(w[2]);writel(0x83000000u|epoch,d->bar+0x14);readl(d->bar+0x14);}
  rc=monitor_wait(d,(w[0]==2?0x86000000u:0x87000000u)|epoch,0x86000000u|epoch,&seen);
 }
 w[5]=seen;if(rc)goto failed;
 if(d->sequence!=w[3]||d->pending||d->runner_uncertain||(readl(d->bar+ODB)&1)){rc=-EPROTO;goto failed;}
 record(d,"MONITOR returned token=%08x sequence=%u pending=0 uncertain=0\n",seen,d->sequence);goto copy;
failed:d->mu_failed=true;d->ready=false;record(d,"MONITOR uncertainty rc=%d; retain resources\n",rc);
copy:session_log_end(d);if(copy_to_user((void __user*)arg,w,sizeof(w)))rc=-EFAULT;
out:mutex_unlock(&d->session_lock);return rc;
}

/* Packet ABI: eight u32 header words + 1536 bytes. Only the session owner can
 * use this; timeout poisons the entire session, and never resumes firmware. */
static int packet_exchange(struct experiment*d,unsigned int token,unsigned int data,unsigned int*value,unsigned long deadline){unsigned int i,seen;
 if(time_after_eq(jiffies,deadline))return -ETIMEDOUT;
 writel(data,d->bar+0x10);readl(d->bar+0x10);writel(token,d->bar+0x14);readl(d->bar+0x14);
 for(i=0;i<20000;i++){
  if(time_after_eq(jiffies,deadline))return -ETIMEDOUT;
  if((readl(d->bar+ODB)&1)||readl(d->bar+0x28)!=0x1fb||readl(d->bar+0x34)!=0xff)return -EPROTO;
  seen=readl(d->bar+0x1c);
  if(seen==(token|0x08000000u)&&readl(d->bar+0x14)==0){*value=readl(d->bar+0x18);return 0;}
  if(d->wad_dma_gen && ((token>>24)==0x75u || (token>>24)==0x76u || ((token>>24)==0x77u && ((token>>16)&255u))) && i<16)cpu_relax();else usleep_range(50,100);
 }
 return -ETIMEDOUT;
}
static long resident_ioctl(struct file*file,unsigned int cmd,unsigned long arg){
 struct experiment*d=file->private_data;unsigned int *w,i,n,v=0,epoch,op;int rc=0;unsigned long deadline;
 if(cmd!=0xc6204d05u)return monitor_ioctl(file,cmd,arg);
 w=memdup_user((void __user*)arg,1568);if(IS_ERR(w))return PTR_ERR(w);
 op=w[0];epoch=w[1];n=w[2];
 if((op!=1&&op!=2)||!epoch||epoch>65535||w[3]||w[4]||w[5]||w[6]||w[7]||(op==1&&(n<20||n>1500))||(op==2&&n)){rc=-EINVAL;goto free;}
 mutex_lock(&d->session_lock);
 if(d->removed||d->pinned||!d->owned||!d->mu_resident||d->pending||d->runner_uncertain||!d->irq_may_run||d->response_ready||d->sequence!=1||d->mu_failed||d->mu_halted){rc=-EBUSY;goto unlock;}
 if(epoch!=d->monitor_epoch){rc=-ESTALE;goto unlock;}
 deadline=jiffies+msecs_to_jiffies(5000);
 if(op==1){
  rc=packet_exchange(d,0xa0000000u|epoch,n,&v,deadline);if(rc)goto uncertain;if(v){rc=-EAGAIN;goto unlock;}
  for(i=0;i<(n+3)/4;i++){rc=packet_exchange(d,0xb0000000u|(i<<16)|epoch,w[8+i],&v,deadline);if(rc)goto uncertain;if(v){rc=-EPROTO;goto uncertain;}}
  rc=packet_exchange(d,0xc0000000u|epoch,0,&v,deadline);if(rc)goto uncertain;if(v){rc=-ESHUTDOWN;goto unlock;}
 }else{
  rc=packet_exchange(d,0xd0000000u|epoch,0,&n,deadline);if(rc)goto uncertain;
  if(n==0xfffffffeu){rc=-ESHUTDOWN;goto unlock;}if(n>1536){rc=-EPROTO;goto uncertain;}
  memset(w+8,0,1536);
  for(i=0;i<(n+3)/4;i++){rc=packet_exchange(d,0xe0000000u|(i<<16)|epoch,0,&w[8+i],deadline);if(rc)goto uncertain;}
  if(n){rc=packet_exchange(d,0xf0000000u|epoch,0,&v,deadline);if(rc)goto uncertain;if(v!=n){rc=-EPROTO;goto uncertain;}}
 }
 w[2]=n;w[3]=d->sequence;w[4]=readl(d->bar+ODB);w[5]=d->pending;w[6]=d->runner_uncertain;
 if(w[4]&1||w[5]||w[6]){rc=-EPROTO;goto uncertain;}
 if(n)record(d,"RESIDENT PIO op=%u bytes=%u sequence=1 pending=0 uncertain=0\n",op,n);
 session_log_end(d);if(copy_to_user((void __user*)arg,w,1568))rc=-EFAULT;goto unlock;
uncertain:d->mu_failed=true;d->ready=false;record(d,"RESIDENT PIO uncertain rc=%d; retain until reboot\n",rc);session_log_end(d);
unlock:mutex_unlock(&d->session_lock);
free:kfree(w);return rc;
}

/* UPL1 PIO mailbox: fixed 32-byte ioctl header + 1024 bytes. Session mutex and
 * epoch checks are shared with networking/control. No firmware doorbell/DMA. */
#ifdef I960_DOOM_PLAY
/* A bounded short spin avoids sleeping through an already-serviced reply.
 * The fallback, absolute deadline, masks, doorbell and completion checks are
 * identical to the scalar reader. The session lock covers both result words. */
static int frame_pair_exchange(struct experiment*d,unsigned token,unsigned*first,unsigned*second,unsigned long deadline){unsigned i,seen;
 if(time_after_eq(jiffies,deadline))return -ETIMEDOUT;
 writel(0,d->bar+0x10);readl(d->bar+0x10);writel(token,d->bar+0x14);readl(d->bar+0x14);
 for(i=0;i<20000;i++){
  if(time_after_eq(jiffies,deadline))return -ETIMEDOUT;
  if((readl(d->bar+ODB)&1)||readl(d->bar+0x28)!=0x1fb||readl(d->bar+0x34)!=0xff)return -EPROTO;
  seen=readl(d->bar+0x1c);
  if(seen==(token|0x08000000u)&&readl(d->bar+0x14)==0){*first=readl(d->bar+0x18);*second=readl(d->bar+0x10);return 0;}
  if(i<16)cpu_relax();else usleep_range(50,100);
 }
 return -ETIMEDOUT;
}
#endif
static long upload_ioctl(struct file*file,unsigned int cmd,unsigned long arg){
 struct experiment*d=file->private_data;unsigned int *w,i,n,v,epoch,op;int rc=0;unsigned long deadline;
 if(cmd!=0xc4204d06u)return resident_ioctl(file,cmd,arg);
 w=memdup_user((void __user*)arg,1056);if(IS_ERR(w))return PTR_ERR(w);
 op=w[0];epoch=w[1];n=w[2];
 if((op!=1&&op!=2
#ifdef I960_DOOM_ENGINE
 &&op!=9&&op!=10
#ifdef I960_DOOM_PLAY
 &&op!=11
#endif
#endif
#ifdef I960_DOOM_RUNTIME
 &&op!=3&&op!=4
#ifdef I960_DOOM_OWNED
 &&op!=5&&op!=6
#ifdef I960_DOOM_CHECKPOINTS
 &&op!=7
#ifdef I960_DOOM_CHECKPOINT_BARRIERS
 &&op!=8
#endif
#endif
#endif
#endif
 )||!epoch||epoch>65535||w[3]||w[4]||w[5]||w[6]||w[7]||(op==1&&(n<32||n>1024||(n&3)))||((op==2||op==3||op==5)&&n)||(op==4&&(n<32||n>544||(n&3)))||(op==6&&n!=32)||(op==7&&n!=4)||(op==8&&n!=8)||((op==9||op==10||op==11)&&n!=8)){rc=-EINVAL;goto free;}
#ifdef I960_DOOM_OWNED
 if(op==6){if(w[8]!=0x3252444fu||!w[9]){rc=-EINVAL;goto free;}for(i=10;i<264;i++)if(w[i]){rc=-EINVAL;goto free;}}
#endif
#ifdef I960_DOOM_CHECKPOINTS
 if(op==7){if(!w[8]||w[8]>512){rc=-EINVAL;goto free;}for(i=9;i<264;i++)if(w[i]){rc=-EINVAL;goto free;}}
#endif
#ifdef I960_DOOM_CHECKPOINT_BARRIERS
 if(op==8){if(!w[8]||w[8]>512||!w[9]){rc=-EINVAL;goto free;}for(i=10;i<264;i++)if(w[i]){rc=-EINVAL;goto free;}}
#endif
#ifdef I960_DOOM_ENGINE
 if(op==10){if((w[8]>2
#ifdef I960_DOOM_DMA
 &&!(w[8]==7&&w[9]<5) /* read-only frozen timing words */
 &&!(w[8]==5&&w[9]==16) /* read-only owned-isolation counter, no DMA submit/address */
#endif
 )||(w[8]==0&&w[9])||(w[8]==2&&w[9]>511)){rc=-EINVAL;goto free;}for(i=10;i<264;i++)if(w[i]){rc=-EINVAL;goto free;}}
 if(op==9||op==11){if(!w[8]||(w[9]&1023)||w[9]>(op==11?65536:131072)-1024){rc=-EINVAL;goto free;}for(i=10;i<264;i++)if(w[i]){rc=-EINVAL;goto free;}}
#endif
 mutex_lock(&d->session_lock);
 if(d->removed||d->pinned||!d->owned||!d->mu_resident||d->pending||d->runner_uncertain||!d->irq_may_run||d->response_ready||d->sequence!=1||d->mu_failed||d->mu_halted){rc=-EBUSY;goto unlock;}
 if(epoch!=d->monitor_epoch){rc=-ESTALE;goto unlock;}
 deadline=jiffies+msecs_to_jiffies(10000);
#ifdef I960_DOOM_ENGINE
 if(op==10){
  rc=packet_exchange(d,0x6b000000u|(w[8]<<16)|epoch,w[9],&v,deadline);if(rc)goto uncertain;
  memset(w+8,0,1024);n=4;w[8]=v;
 }
 else
#ifdef I960_DOOM_PLAY
 if(op==11){
  rc=packet_exchange(d,0x6c000000u|epoch,w[8],&v,deadline);if(rc)goto uncertain;if(v){rc=-ESTALE;goto unlock;}
  rc=packet_exchange(d,0x6d000000u|epoch,w[9],&v,deadline);if(rc)goto uncertain;if(v){rc=-ESTALE;goto unlock;}
  memset(w+8,0,1024);n=1024;
  for(i=0;i<128;i++){rc=frame_pair_exchange(d,0x6f000000u|(i<<16)|epoch,&w[8+2*i],&w[9+2*i],deadline);if(rc)goto uncertain;}
 }
 else
#endif
 if(op==9){
  rc=packet_exchange(d,0x6c000000u|epoch,w[8],&v,deadline);if(rc)goto uncertain;if(v){rc=-ESTALE;goto unlock;}
  rc=packet_exchange(d,0x6d000000u|epoch,w[9],&v,deadline);if(rc)goto uncertain;if(v){rc=-ESTALE;goto unlock;}
  memset(w+8,0,1024);n=1024;
  for(i=0;i<256;i++){rc=packet_exchange(d,0x6e000000u|(i<<16)|epoch,0,&w[8+i],deadline);if(rc)goto uncertain;}
 }
 else
#endif
#ifdef I960_DOOM_CHECKPOINT_BARRIERS
 if(op==8){
  rc=packet_exchange(d,0x7f000000u|epoch,w[8],&v,deadline);if(rc)goto uncertain;if(v){rc=-ESTALE;goto unlock;}
  rc=packet_exchange(d,0x7f010000u|epoch,w[9],&v,deadline);if(rc)goto uncertain;if(v){rc=-ESTALE;goto unlock;}
 }
 else
#endif
#ifdef I960_DOOM_OWNED
 if(op==6){rc=packet_exchange(d,0x7a000000u|epoch,w[9],&v,deadline);if(rc)goto uncertain;if(v){rc=-ESTALE;goto unlock;}}
 else
#endif
 if(op==1||op==4){
  rc=packet_exchange(d,(op==1?0x70000000u:0x77000000u)|epoch,n,&v,deadline);if(rc)goto uncertain;if(v){rc=-EAGAIN;goto unlock;}
  for(i=0;i<n/4;i++){rc=packet_exchange(d,(op==1?0x71000000u:0x78000000u)|(i<<16)|epoch,w[8+i],&v,deadline);if(rc)goto uncertain;if(v){rc=-EPROTO;goto uncertain;}}
  rc=packet_exchange(d,(op==1?0x72000000u:0x79000000u)|epoch,0,&v,deadline);if(rc)goto uncertain;if(v){rc=-ESHUTDOWN;goto unlock;}
 }else{
  rc=packet_exchange(d,(op==2?0x74000000u:op==5?0x7b000000u:op==7?0x7d000000u:0x75000000u)|epoch,op==7?w[8]:0,&v,deadline);if(rc)goto uncertain;if(v){rc=-EPROTO;goto uncertain;}
  memset(w+8,0,1024);n=op==2?64:32;
  for(i=0;i<n/4;i++){rc=packet_exchange(d,(op==2?0x73000000u:op==5?0x7c000000u:op==7?0x7e000000u:0x76000000u)|(i<<16)|epoch,0,&w[8+i],deadline);if(rc)goto uncertain;}
 }
 w[2]=n;w[3]=d->sequence;w[4]=readl(d->bar+ODB);w[5]=d->pending;w[6]=d->runner_uncertain;
 if(w[4]&1||w[5]||w[6]){rc=-EPROTO;goto uncertain;}
 session_log_end(d);if(copy_to_user((void __user*)arg,w,1056))rc=-EFAULT;goto unlock;
uncertain:d->mu_failed=true;d->ready=false;record(d,"RESIDENT UPLOAD uncertain rc=%d; retain until reboot\n",rc);session_log_end(d);
unlock:mutex_unlock(&d->session_lock);
free:kfree(w);return rc;
}

/* Failure-only frozen fault report. Never clears poison, ACKs a frame, changes
 * DMA registers or permits reuse. At most 2 seconds and 2000 polls per word. */
static void frame_dma_terminal(struct experiment*d,unsigned epoch){
 unsigned i,j,v=0,rc=0;unsigned long end=jiffies+msecs_to_jiffies(2000);
 d->frame_dma_fault[0]=0x31464446;d->frame_dma_fault[1]=epoch;
 for(i=0;i<96;i++){
  writel(0x91000000u|(i<<16)|epoch,d->bar+0x14);readl(d->bar+0x14);
  for(j=0;j<2000;j++){
   if(time_after_eq(jiffies,end)){rc=1;break;}
   if((readl(d->bar+ODB)&1)||readl(d->bar+0x28)!=0x1fb||readl(d->bar+0x34)!=0xff){rc=2;break;}
   if(readl(d->bar+0x1c)==(0x92000000u|(i<<16)|epoch)&&!readl(d->bar+0x14)){v=readl(d->bar+0x18);break;}
   usleep_range(50,100);
  }
  if(rc||j==2000){if(!rc)rc=3;break;}
  d->frame_dma_fault[4+i]=v;d->frame_dma_fault[2]=i+1;
  if((i==0&&v!=0x31464d4e)||(i==1&&v!=epoch)){rc=4;break;}
 }
 d->frame_dma_fault[3]=rc;d->frame_dma_fault_blob.data=d->frame_dma_fault;d->frame_dma_fault_blob.size=sizeof(d->frame_dma_fault);
 debugfs_create_blob("frame-dma-fault.bin",0400,d->directory,&d->frame_dma_fault_blob);
 record(d,"FRAME DMA diagnostic words=%u rc=%u; session remains poisoned\n",d->frame_dma_fault[2],rc);
}
#define FRAME_DMA_DIAG(d,e) frame_dma_terminal(d,e)

/* Dedicated coherent mapping, never freed after resident ownership. No user
 * DMA address is accepted. The renderer pin spans submit, validation and ACK. */
#include <linux/crc32.h>
#define FRAME_DMA_BYTES 73728u
#ifndef FRAME_DMA_DIAG
#define FRAME_DMA_DIAG(d,e) ((void)0)
#endif
static long frame_dma_ioctl(struct file*file,unsigned cmd,unsigned long arg){
 struct experiment*d=file->private_data;unsigned*w,op,epoch,g,off,i,v=0;int rc=0;unsigned long deadline;
 if(cmd!=0xc4204d08u)return upload_ioctl(file,cmd,arg);
 w=memdup_user((void __user*)arg,1056);if(IS_ERR(w))return PTR_ERR(w);
 op=w[0];epoch=w[1];g=w[2];off=w[3];
 if(op<1||op>3||!epoch||epoch>65535||!g||w[4]||w[5]||w[6]||w[7]||(op==2&&off)||(op==1&&off>1)||(op==3&&((off&1023)||off>72704))){rc=-EINVAL;goto free;}
 for(i=8;i<264;i++)if(w[i]){rc=-EINVAL;goto free;}
 mutex_lock(&d->session_lock);
 if(d->removed||d->pinned||!d->owned||!d->mu_resident||d->pending||d->runner_uncertain||!d->irq_may_run||d->response_ready||d->sequence!=1||d->mu_failed||d->mu_halted){rc=-EBUSY;goto unlock;}
 if(epoch!=d->monitor_epoch){rc=-ESTALE;goto unlock;}
 if(op==3){
  if(!d->frame_dma_valid||g!=d->frame_dma_gen){rc=-ESTALE;goto unlock;}
  dma_rmb();memcpy(w+8,(u8*)d->frame_dma_buf+off,1024);goto copy;
 }
 deadline=jiffies+msecs_to_jiffies(10000);
 if(op==1){
  if(d->frame_dma_pending){rc=-EBUSY;goto unlock;}
  if(g<=d->frame_dma_gen){rc=-ESTALE;goto unlock;}
  rc=packet_exchange(d,0x6b000000u|epoch,0,&v,deadline);if(rc)goto uncertain;if(v!=g){rc=-ESTALE;goto unlock;}
  if(!d->frame_dma_buf){
   d->frame_dma_buf=dma_alloc_coherent(&d->pdev->dev,FRAME_DMA_BYTES,&d->frame_dma_bus,GFP_KERNEL);if(!d->frame_dma_buf){rc=-ENOMEM;goto unlock;}
   if(d->frame_dma_bus>0xffffffffULL-FRAME_DMA_BYTES){dma_free_coherent(&d->pdev->dev,FRAME_DMA_BYTES,d->frame_dma_buf,d->frame_dma_bus);d->frame_dma_buf=NULL;rc=-ERANGE;goto unlock;}
   d->frame_dma_blob.data=d->frame_dma_buf;d->frame_dma_blob.size=FRAME_DMA_BYTES;debugfs_create_blob("frame-dma-buffer.bin",0400,d->directory,&d->frame_dma_blob);
  }
  d->frame_dma_no_crc=off;
  rc=packet_exchange(d,0x6b060000u|epoch,off,&v,deadline);if(rc||v)goto uncertain;
  d->frame_dma_valid=false;memset(d->frame_dma_buf,0xa5,FRAME_DMA_BYTES);dma_wmb();
  rc=packet_exchange(d,0x6b030000u|epoch,(unsigned)d->frame_dma_bus+4096,&v,deadline);if(rc||v)goto uncertain;
  d->frame_dma_gen=g;d->frame_dma_pending=true;
  rc=packet_exchange(d,0x6b040000u|epoch,g,&v,deadline);if(rc||v)goto uncertain;goto copy;
 }
 if(!d->frame_dma_pending||g!=d->frame_dma_gen){rc=-ESTALE;goto unlock;}
 rc=packet_exchange(d,0x6b050000u|epoch,1,&v,deadline);if(rc)goto uncertain;
 if(v==1){rc=-EAGAIN;goto unlock;}if(v!=2){rc=-EPROTO;goto uncertain;}
 for(i=0;i<16;i++){rc=packet_exchange(d,0x6b050000u|epoch,i,w+8+i,deadline);if(rc)goto uncertain;}
 if(w[8]!=0x314d4446||w[9]!=2||w[10]!=g||w[11]!=(unsigned)d->frame_dma_bus+4096||w[12]<0xc0240000||w[12]>0xc0e30000||w[13]!=w[14]||w[15]||w[16]!=w[23]||w[17]||w[18]||w[19]!=7||w[20]>=200000||w[21]||w[22]!=d->frame_dma_no_crc||(w[22]&&w[13])||w[23]<0xc0f4c010||w[23]>0xc0f8bfe0||(w[23]&31)){rc=-EPROTO;goto uncertain;}
 dma_rmb();
 for(i=0;i<4096;i++)if(((u8*)d->frame_dma_buf)[i]!=0xa5||((u8*)d->frame_dma_buf)[69632+i]!=0xa5){rc=-EILSEQ;goto uncertain;}
 if(!d->frame_dma_no_crc&&(crc32_le(~0u,(u8*)d->frame_dma_buf+4096,65536)^~0u)!=w[13]){rc=-EILSEQ;goto uncertain;}
 rc=packet_exchange(d,0x6b000000u|epoch,0,&v,deadline);if(rc)goto uncertain;if(v!=g){rc=-ESTALE;goto uncertain;}
 d->frame_dma_pending=false;d->frame_dma_valid=true;
 record(d,"FRAME DMA generation=%u checksum=%08x complete; ownership and guards validated\n",g,w[13]);
copy:session_log_end(d);if(copy_to_user((void __user*)arg,w,1056))rc=-EFAULT;goto unlock;
uncertain:if(!rc)rc=-EIO;d->frame_dma_valid=false;d->mu_failed=true;d->ready=false;record(d,"FRAME DMA uncertain rc=%d target=%u; retain mapping and image\n",rc,v);FRAME_DMA_DIAG(d,epoch);session_log_end(d);
unlock:mutex_unlock(&d->session_lock);
free:kfree(w);return rc;
}

/* Fixed 4 KiB host-to-card block. No user-provided bus/card address. */
static long wad_dma_ioctl(struct file*file,unsigned cmd,unsigned long arg){
 struct experiment*d=file->private_data;unsigned *w,op,epoch,g,i,v=0,q[8];int rc=0;unsigned long deadline;
 if(cmd!=0xd0204d09u)return frame_dma_ioctl(file,cmd,arg);
 w=memdup_user((void __user*)arg,4128);if(IS_ERR(w))return PTR_ERR(w);
 op=w[0];epoch=w[1];g=w[2];
 if((op!=1&&op!=2)||!epoch||epoch>65535||!g||w[6]||w[7]||!w[4]||w[4]>4096||w[3]>=w[5]){rc=-EINVAL;goto free;}
 if(op==2){for(i=8;i<1032;i++)if(w[i]){rc=-EINVAL;goto free;}}
 else {unsigned n=min(w[4],w[5]-w[3]);for(i=n;i<4096;i++)if(((u8*)(w+8))[i]){rc=-EINVAL;goto free;}}
 mutex_lock(&d->session_lock);
 if(d->removed||d->pinned||!d->owned||!d->mu_resident||d->pending||d->runner_uncertain||!d->irq_may_run||d->response_ready||d->sequence!=1||d->mu_failed||d->mu_halted){rc=-EBUSY;goto unlock;}
 if(epoch!=d->monitor_epoch){rc=-ESTALE;goto unlock;}
 deadline=jiffies+msecs_to_jiffies(10000);
 if(op==1){
  if(d->wad_dma_pending){rc=-EBUSY;goto unlock;}
  if(g<=d->wad_dma_gen){rc=-ESTALE;goto unlock;}
  rc=packet_exchange(d,0x75000000u|epoch,0,&v,deadline);if(rc||v)goto uncertain;
  for(i=0;i<8;i++){rc=packet_exchange(d,0x76000000u|(i<<16)|epoch,0,q+i,deadline);if(rc)goto uncertain;}
  if(q[0]!=0x31424157||q[1]!=g||q[2]!=1||q[3]!=1||q[4]!=w[3]||q[5]!=w[4]||q[6]!=w[5]){rc=-ESTALE;goto unlock;}
  if(!d->wad_dma_buf){
   d->wad_dma_buf=dma_alloc_coherent(&d->pdev->dev,12288,&d->wad_dma_bus,GFP_KERNEL);if(!d->wad_dma_buf){rc=-ENOMEM;goto unlock;}
   if(d->wad_dma_bus>0xffffffffULL-12288||(d->wad_dma_bus&3)){dma_free_coherent(&d->pdev->dev,12288,d->wad_dma_buf,d->wad_dma_bus);d->wad_dma_buf=NULL;rc=-ERANGE;goto unlock;}
  }
  memset(d->wad_dma_buf,0xa5,12288);memcpy((u8*)d->wad_dma_buf+4096,w+8,4096);dma_wmb();
  for(i=0;i<3;i++)d->wad_dma_geometry[i]=w[3+i];
  rc=packet_exchange(d,0x77010000u|epoch,(unsigned)d->wad_dma_bus+4096,&v,deadline);if(rc||v)goto uncertain;
  d->wad_dma_gen=g;d->wad_dma_pending=true;
  rc=packet_exchange(d,0x77020000u|epoch,g,&v,deadline);if(rc||v)goto uncertain;
  memset(w+8,0,4096);goto copy;
 }
 if(!d->wad_dma_pending||g!=d->wad_dma_gen){rc=-ESTALE;goto unlock;}
 for(i=0;i<3;i++)if(w[3+i]!=d->wad_dma_geometry[i]){rc=-ESTALE;goto unlock;}
 rc=packet_exchange(d,0x77030000u|epoch,0,&v,deadline);if(rc)goto uncertain;
 if(v==1){rc=-EAGAIN;goto unlock;}if(v!=2){rc=-EPROTO;goto uncertain;}
 for(i=0;i<12;i++){rc=packet_exchange(d,0x77040000u|epoch,i,w+8+i,deadline);if(rc)goto uncertain;}
 if(w[8]!=g||w[9]!=(unsigned)d->wad_dma_bus+4096||w[10]<0xc0241000||w[10]>0xc0e2e000||(w[10]&3)||w[11]!=4096||w[12]||w[13]!=w[18]||w[14]||w[15]||w[16]!=6||w[17]>=200000||w[18]<0xc0f4c010||w[18]>0xc0f8bfe0||(w[18]&31)||w[19]){rc=-EPROTO;goto uncertain;}
 dma_rmb();for(i=0;i<4096;i++)if(((u8*)d->wad_dma_buf)[i]!=0xa5||((u8*)d->wad_dma_buf)[8192+i]!=0xa5){rc=-EILSEQ;goto uncertain;}
 rc=packet_exchange(d,0x77050000u|epoch,g,&v,deadline);if(rc||v)goto uncertain;
 d->wad_dma_pending=false;
copy:session_log_end(d);if(copy_to_user((void __user*)arg,w,4128))rc=-EFAULT;goto unlock;
uncertain:if(!rc)rc=-EIO;d->mu_failed=true;d->ready=false;record(d,"WAD DMA uncertain rc=%d; retain mappings until reboot\n",rc);session_log_end(d);
unlock:mutex_unlock(&d->session_lock);
free:kfree(w);return rc;
}

/* Two persistent coherent destinations. No userspace DMA address is accepted.
 * Completion/read are host-RAM-only. RELEASE is one bounded control write.
 * Mapping lifetime is the retained resident session, including all failures. */
#define PP_BYTES 73728u
#define PP_MARK 73696u
static long pingpong_ioctl(struct file*file,unsigned cmd,unsigned long arg){
 struct experiment*d=file->private_data;unsigned*w,op,epoch,g,off,i,slot,v=0,*m;int rc=0;unsigned long deadline;
 if(cmd!=0xc4204d0au)return wad_dma_ioctl(file,cmd,arg);
 w=memdup_user((void __user*)arg,1056);if(IS_ERR(w))return PTR_ERR(w);
 op=w[0];epoch=w[1];g=w[2];off=w[3];slot=(g-1)&1;
 if(op<1||op>8||!epoch||epoch>65535||w[4]||w[5]||w[6]||w[7]||(op==1&&(g||off))||((op>=2&&op<=4||op==8)&&!g)||(op!=3&&op!=8&&off)||(op==8&&off!=PP_BYTES)||(op==3&&((off&1023)||off>72704))){rc=-EINVAL;goto free;}
 for(i=8;i<264;i++)if(w[i]){rc=-EINVAL;goto free;}
 mutex_lock(&d->session_lock);
 if(d->removed||d->pinned||!d->owned||!d->mu_resident||d->pending||d->runner_uncertain||!d->irq_may_run||d->response_ready||d->sequence!=1||d->mu_failed||d->mu_halted){rc=-EBUSY;goto unlock;}
 if(epoch!=d->monitor_epoch){rc=-ESTALE;goto unlock;}
 deadline=jiffies+msecs_to_jiffies(10000);
 if(op==1){
  if(d->pp_enabled||d->pp_buf[0]||d->pp_buf[1]){rc=-EBUSY;goto unlock;}
  for(i=0;i<2;i++){
   d->pp_buf[i]=dma_alloc_coherent(&d->pdev->dev,PP_BYTES,&d->pp_bus[i],GFP_KERNEL);
   if(!d->pp_buf[i]){rc=-ENOMEM;goto uncertain;}
   if(d->pp_bus[i]>0xffffffffULL-PP_BYTES){rc=-ERANGE;goto uncertain;}
   memset(d->pp_buf[i],0xa5,PP_BYTES);d->pp_next[i]=i+1;
  }
  dma_wmb();
  for(i=0;i<2;i++){rc=packet_exchange(d,0x6b000000u|((8+i)<<16)|epoch,(unsigned)d->pp_bus[i]+4096,&v,deadline);if(rc||v)goto uncertain;w[8+i]=(unsigned)d->pp_bus[i];}
  d->pp_enabled=true;goto copy;
 }
 if(!d->pp_enabled){rc=-EINVAL;goto unlock;}
 if(op==6){
  if(d->pp_running||!g||(g&1)!=1){rc=-EINVAL;goto unlock;}
  d->pp_next[0]=g;d->pp_next[1]=g+1;
  rc=packet_exchange(d,0x6b0a0000u|epoch,1,&v,deadline);if(rc||v)goto uncertain;d->pp_running=true;goto copy;
 }
 if(op==7){rc=packet_exchange(d,0x6b0c0000u|epoch,5,w+8,deadline);if(rc)goto uncertain;goto copy;}
 if(op==5){for(i=0;i<6;i++){rc=packet_exchange(d,0x6b0c0000u|epoch,i==5?6:i,w+8+i,deadline);if(rc)goto uncertain;}goto copy;}
 if(!d->pp_running){rc=-EINVAL;goto unlock;}
 if(g!=d->pp_next[slot]){rc=-ESTALE;goto unlock;}
 m=(unsigned*)((u8*)d->pp_buf[slot]+PP_MARK);
 if(READ_ONCE(m[7])!=g){rc=-EAGAIN;goto unlock;}
 dma_rmb();
 if(m[0]!=0x31505044u||m[1]!=g||m[2]!=slot||m[3]!=65536||(m[4]&3)||m[4]<0xc0240000u||m[4]>0xc0e30000u||m[6]!=~g||READ_ONCE(m[7])!=g){rc=-EPROTO;goto uncertain;}
 if(op==2||op==8){
  for(i=0;i<4096;i++)if(((u8*)d->pp_buf[slot])[i]!=0xa5){rc=-EILSEQ;goto uncertain;}
  for(i=69632;i<PP_MARK;i++)if(((u8*)d->pp_buf[slot])[i]!=0xa5){rc=-EILSEQ;goto uncertain;}
  if(op==8){
   /* The slot stays owned under session_lock throughout the full copy.
    * No release credit on a short/faulting userspace copy. */
   if(copy_to_user((u8 __user*)arg+32,d->pp_buf[slot],PP_BYTES)){rc=-EFAULT;goto unlock;}
   d->pp_reads[slot][0]=~0u;d->pp_reads[slot][1]=~0u;d->pp_reads[slot][2]=255;
   goto unlock;
  }
  memcpy(w+8,m,32);goto copy;
 }
 if(op==3){memcpy(w+8,(u8*)d->pp_buf[slot]+off,1024);goto copy;}
 if(d->pp_reads[slot][0]!=~0u||d->pp_reads[slot][1]!=~0u||d->pp_reads[slot][2]!=255){rc=-EBUSY;goto unlock;}
 rc=packet_exchange(d,0x6b0b0000u|epoch,g,&v,deadline);if(rc||v)goto uncertain;
 memset(d->pp_reads[slot],0,sizeof(d->pp_reads[slot]));d->pp_next[slot]+=2;
copy:session_log_end(d);if(copy_to_user((void __user*)arg,w,1056))rc=-EFAULT;else if(op==3){i=off/1024;d->pp_reads[slot][i/32]|=1u<<(i%32);}goto unlock;
uncertain:if(!rc)rc=-EIO;d->mu_failed=true;d->ready=false;record(d,"PINGPONG uncertain rc=%d; retain both mappings\n",rc);FRAME_DMA_DIAG(d,epoch);session_log_end(d);
unlock:mutex_unlock(&d->session_lock);
free:kfree(w);return rc;
}

#ifndef I960_WAD_RING_WIRE_H
#define I960_WAD_RING_WIRE_H
/* Wire words are 32-bit little endian, never native pointers. Single producer
 * per record. Publish word 7 last; acquire before reading the other words. */
#define WR_SLOTS 2u
#define WR_BLOCK 32768u
#define WR_BATCH (WR_SLOTS*WR_BLOCK)
#define WR_BYTES 40960u
#define WR_REQUEST 4096u
#define WR_RESPONSE 4160u
#define WR_COMPLETE 4224u
#define WR_DATA 4288u
#define WR_REQ_MAGIC 0x31515257u
#define WR_RSP_MAGIC 0x31535257u
#define WR_END_MAGIC 0x31435257u
struct wr_record { unsigned w[16]; };
static void wr_record_make(struct wr_record*r,unsigned magic,unsigned gen,
                           unsigned offset,unsigned length,unsigned total){
 unsigned i;for(i=0;i<16;i++)r->w[i]=0;
 r->w[0]=magic;r->w[1]=gen;r->w[2]=(gen-1u)&1u;r->w[3]=offset;
 r->w[4]=length;r->w[5]=total;r->w[6]=~gen;r->w[7]=gen;
}
static unsigned wr_record_valid(const struct wr_record*r,unsigned magic,
                                unsigned gen,unsigned total){
 unsigned i;if(!gen||r->w[0]!=magic||r->w[1]!=gen||r->w[2]!=((gen-1u)&1u)||
 r->w[5]!=total||!total||total>268435456u||r->w[6]!=~gen||r->w[7]!=gen||
 r->w[3]>=total||(r->w[3]&(WR_BLOCK-1u))||!r->w[4]||r->w[4]>WR_BLOCK||
 r->w[4]!=((total-r->w[3]<WR_BLOCK)?total-r->w[3]:WR_BLOCK))return 0;
 for(i=8;i<16;i++)if(r->w[i])return 0;return 1;
}
static unsigned wr_record_matches(const struct wr_record*a,const struct wr_record*b){
 unsigned i;for(i=1;i<16;i++)if(a->w[i]!=b->w[i])return 0;return 1;
}
#endif

/* Retained coherent slots; userspace supplies bytes, never DMA addresses. */
static long wad_ring_ioctl(struct file*file,unsigned cmd,unsigned long arg){
 struct experiment*d=file->private_data;unsigned*w,op,epoch,slot,i,g,v=0;int rc=0;
 unsigned char*b;struct wr_record *request,*response,*complete;unsigned long deadline;
 if(cmd!=0xc0204d0bu)return pingpong_ioctl(file,cmd,arg);
 w=memdup_user((void __user*)arg,32+WR_BLOCK);if(IS_ERR(w))return PTR_ERR(w);
 op=w[0];epoch=w[1];slot=w[2];g=w[3];
 if(op<1||op>4||!epoch||epoch>65535||slot>=2||w[7]||((op==2||op==4)&&(w[4]||w[5]))||(op==1&&(slot||g||w[4]||w[5]||!w[6]||w[6]>268435456u))){rc=-EINVAL;goto free;}
 if(op!=3)for(i=8;i<8+WR_BLOCK/4;i++)if(w[i]){rc=-EINVAL;goto free;}
 mutex_lock(&d->session_lock);
 if(d->removed||d->pinned||!d->owned||!d->mu_resident||d->pending||d->runner_uncertain||!d->irq_may_run||d->response_ready||d->sequence!=1||d->mu_failed||d->mu_halted){rc=-EBUSY;goto unlock;}
 if(epoch!=d->monitor_epoch){rc=-ESTALE;goto unlock;}
 deadline=jiffies+msecs_to_jiffies(10000);
 if(op==1){
  if(d->wr_buf[0]||d->wr_buf[1]){rc=-EBUSY;goto unlock;}
  for(i=0;i<2;i++){
   d->wr_buf[i]=dma_alloc_coherent(&d->pdev->dev,WR_BYTES,&d->wr_bus[i],GFP_KERNEL);
   if(!d->wr_buf[i]||d->wr_bus[i]>0xffffffffULL-WR_BYTES||(d->wr_bus[i]&63)){rc=-ENOMEM;goto uncertain;}
   memset(d->wr_buf[i],0xa5,WR_BYTES);memset((u8*)d->wr_buf[i]+WR_REQUEST,0,192);
   d->wr_next[i]=i+1;
  }
  d->wr_total=w[6];dma_wmb();
  for(i=0;i<2;i++){rc=packet_exchange(d,0x77000000u|((6+i)<<16)|epoch,(unsigned)d->wr_bus[i],&v,deadline);if(rc||v)goto uncertain;w[8+i]=(unsigned)d->wr_bus[i];}
  goto copy;
 }
 if(!d->wr_buf[slot]||w[6]!=d->wr_total||!g||((g-1)&1)!=slot||g+(op==4?2:0)!=d->wr_next[slot]){rc=-ESTALE;goto unlock;}
 b=d->wr_buf[slot];request=(void*)(b+WR_REQUEST);response=(void*)(b+WR_RESPONSE);complete=(void*)(b+WR_COMPLETE);
 if(READ_ONCE(request->w[7])!=g){rc=-EAGAIN;goto unlock;}dma_rmb();
 if(!wr_record_valid(request,WR_REQ_MAGIC,g,d->wr_total)||READ_ONCE(request->w[7])!=g){rc=-EPROTO;goto uncertain;}
 if(op!=4&&g>2&&(!wr_record_valid(complete,WR_END_MAGIC,g-2,d->wr_total)||!wr_record_matches(complete,response))){rc=-EPROTO;goto uncertain;}
 for(i=0;i<WR_REQUEST;i++)if(b[i]!=0xa5){rc=-EILSEQ;goto uncertain;}
 for(i=WR_DATA+WR_BLOCK;i<WR_BYTES;i++)if(b[i]!=0xa5){rc=-EILSEQ;goto uncertain;}
 if(op==4){
  if(!wr_record_valid(complete,WR_END_MAGIC,g,d->wr_total)||!wr_record_matches(complete,response)||!wr_record_matches(complete,request)){rc=-EPROTO;goto uncertain;}
  memcpy(w+8,request,64);memcpy(w+24,response,64);memcpy(w+40,complete,64);goto copy;
 }
 if(op==2){if(w[4]||w[5]){rc=-EINVAL;goto unlock;}memcpy(w+8,request,64);memcpy(w+24,complete,64);goto copy;}
 if(w[4]!=request->w[3]||w[5]!=request->w[4]){rc=-ESTALE;goto unlock;}
 for(i=w[5];i<WR_BLOCK;i++)if(((u8*)(w+8))[i]){rc=-EINVAL;goto unlock;}
 memcpy(b+WR_DATA,w+8,WR_BLOCK);
 /* Header plus payload become visible before the committed generation. */
 response->w[7]=0;for(i=0;i<16;i++)if(i!=7)response->w[i]=request->w[i];response->w[0]=WR_RSP_MAGIC;
 dma_wmb();WRITE_ONCE(response->w[7],g);d->wr_next[slot]+=2;
 memset(w+8,0,WR_BLOCK);memcpy(w+8,response,64);
copy:session_log_end(d);if(copy_to_user((void __user*)arg,w,32+WR_BLOCK))rc=-EFAULT;goto unlock;
uncertain:if(!rc)rc=-EIO;d->mu_failed=true;d->ready=false;record(d,"WAD ring uncertain rc=%d; retain mappings until reboot\n",rc);session_log_end(d);
unlock:mutex_unlock(&d->session_lock);
free:kfree(w);return rc;
}

static const struct file_operations session_fops={
    .owner=THIS_MODULE,.unlocked_ioctl=wad_ring_ioctl,.open=session_file_open,.write=session_file_write,
    .read=session_file_read,.release=session_file_release,.llseek=no_llseek,
};

static int probe(struct pci_dev *pdev, const struct pci_device_id *id)
{
    static const char *names[] = {
        "enquiry-before.bin", "read-a5.bin", "read-5a.bin", "enquiry-after.bin",
        "control-a5.bin", "control-5a.bin", "code-a5.bin", "code-5a.bin",
        "globals-a5.bin", "globals-5a.bin", "board-a5.bin", "board-5a.bin",
        "scratch-before-a5.bin", "scratch-before-5a.bin", "scratch-test-a5.bin",
        "scratch-test-5a.bin", "scratch-restored-a5.bin", "scratch-restored-5a.bin",
        "upload-test.bin", "upload-restore.bin", "dram-hook-a5.bin", "dram-hook-5a.bin",
        "rom-table-a5.bin", "rom-table-5a.bin",
        "exec-ram-before-a5.bin", "exec-ram-before-5a.bin",
        "exec-flash-before-a5.bin", "exec-flash-before-5a.bin",
        "exec-ram-upload.bin", "exec-ram-after-a5.bin", "exec-ram-after-5a.bin",
        "exec-table-ram-upload.bin", "exec-table-ram-a5.bin", "exec-table-ram-5a.bin",
        "exec-ram-completion.bin", "exec-flash-upload.bin",
        "exec-flash-after-a5.bin", "exec-flash-after-5a.bin",
        "exec-table-flash-upload.bin", "exec-table-flash-a5.bin", "exec-table-flash-5a.bin",
        "exec-flash-completion.bin", "exec-table-restore-upload.bin",
        "exec-table-restored-a5.bin", "exec-table-restored-5a.bin",
        "exec-ram-restore-upload.bin", "exec-ram-restored-a5.bin", "exec-ram-restored-5a.bin",
        "exec-flash-restore-upload.bin", "exec-flash-restored-a5.bin",
        "exec-flash-restored-5a.bin", "exec-stock-completion.bin",
        "exec-flash-followup.bin", "exec-stock-followup.bin"
    };
    struct experiment *d;
    unsigned int i;
    int rc;
    if (strcmp(pci_name(pdev), bdf)) return -ENODEV;
    if (!stage_check || !firmware_name) return -EINVAL;
    if (stage_check && (!runtime_check || scratch_check || dram_hook_check ||
                        rom_table_check || rom_exec_check || flash_map_check)) return -EINVAL;
    if (scratch_check && !runtime_check) return -EINVAL;
    if (dram_hook_check && (!runtime_check || scratch_check)) return -EINVAL;
    if (rom_table_check && (!runtime_check || scratch_check || dram_hook_check || rom_exec_check || flash_map_check)) return -EINVAL;
    if (rom_exec_check && (!runtime_check || scratch_check || dram_hook_check || rom_table_check || flash_map_check)) return -EINVAL;
    if (flash_map_check && (!runtime_check || scratch_check || dram_hook_check || rom_table_check || rom_exec_check)) return -EINVAL;
    if (runtime_check && !pointer_check) return -EINVAL;
    if (pointer_check && (attempt || length != 512 || flash_offset)) return -EINVAL;
    if (!length || length > MAX_READ || (length & 3) ||
        (flash_offset & 3) || flash_offset > IMAGE_WINDOW - length) return -EINVAL;
    if (!(pci_resource_flags(pdev, 0) & IORESOURCE_MEM) ||
        pci_resource_len(pdev, 0) < 0x2000) return -ENODEV;
    d = kzalloc(sizeof(*d), GFP_KERNEL);
    if (!d) return -ENOMEM;
    d->pdev = pdev;
    mutex_init(&d->session_lock);
    kref_init(&d->refs);
    rc = request_firmware(&d->payload, firmware_name, &pdev->dev);
    if (rc) goto free_state;
    if (d->payload->size > LOAD_MAX || !load_valid(d->payload->size, entry_offset)) { rc=-EINVAL; goto free_state; }
    if (buffer_io && (d->payload->size != BIO_IMAGE_SIZE || entry_offset >= 0x20000u ||
        payload_argument != BIO_BASE || !bio_request_valid(d->payload->data+BIO_OFFSET))) {
        rc=-EINVAL; goto free_state;
    }
    pci_read_config_word(pdev, PCI_COMMAND, &d->saved_command);
    rc = pci_enable_device(pdev);
    if (rc) goto free_state;
    rc = pci_request_regions(pdev, "dac960auto");
    if (rc) goto disable;
    rc = dma_set_mask_and_coherent(&pdev->dev, DMA_BIT_MASK(32));
    if (rc) goto release;
    d->bar = pci_iomap(pdev, 0, 0x2000);
    if (!d->bar) { rc = -ENOMEM; goto release; }
    d->dma_buf = dma_alloc_coherent(&pdev->dev, DMA_SIZE, &d->dma, GFP_KERNEL);
    if (!d->dma_buf) { rc = -ENOMEM; goto unmap; }
    for (i = 0; i < 54; i++) {
        d->capture[i].blob.size = (i == 1 || i == 2) ? (pointer_check ? 4 : length) : 512;
        if (i == 6 || i == 7) d->capture[i].blob.size = 16;
        if (i == 8 || i == 9) d->capture[i].blob.size = 8;
        if (i >= 12 && i <= 17) d->capture[i].blob.size = SCRATCH_REGION_SIZE;
        if (i >= 18) d->capture[i].blob.size = SCRATCH_WRITE_SIZE;
        if (i >= 20) d->capture[i].blob.size = DRAM_HOOK_SIZE;
        if (i >= 22) d->capture[i].blob.size = 4;
        if (i >= 24) d->capture[i].blob.size = EXEC_REGION_SIZE;
        if (i == 28 || i == 45) d->capture[i].blob.size = EXEC_RAM_SIZE;
        if (i == 35 || i == 48) d->capture[i].blob.size = EXEC_FLASH_SIZE;
        if (flash_map_check && i >= 24 && i <= 29) d->capture[i].blob.size = 64;
        if (i == 31 || i == 32 || i == 33 || i == 38 || i == 39 || i == 40 ||
            i == 42 || i == 43 || i == 44) d->capture[i].blob.size = 4;
        if (i == 34 || i == 41 || i == 51 || i == 52 || i == 53)
            d->capture[i].blob.size = 16;
        if (i == 20 || i == 21) d->capture[i].blob.size = 16;
        d->capture[i].data = kzalloc(d->capture[i].blob.size, GFP_KERNEL);
        if (!d->capture[i].data) { rc = -ENOMEM; goto free_dma; }
        d->capture[i].blob.data = d->capture[i].data;
    }
    if (stage_check) {
        for (i = 0; i < ARRAY_SIZE(d->stage); i++) {
            d->stage[i].data = kvzalloc(IMAGE_WINDOW, GFP_KERNEL);
            if (!d->stage[i].data) { rc = -ENOMEM; goto free_dma; }
            d->stage[i].blob.data = d->stage[i].data;
            d->stage[i].blob.size = IMAGE_WINDOW;
        }
    }
    d->saved_irq = readl(d->bar + IRQMASK);
    pci_set_master(pdev);
    writel(~0u, d->bar + IRQMASK);
    readl(d->bar + IRQMASK);
    record(d, "bdf=%s attempt=%u length=%u offset=%08x saved-irq=%08x\n",
           pci_name(pdev), attempt, length, flash_offset, d->saved_irq);
    rc = run(d);
    record(d, "experiment-result=%d pending=%u; exported files are captures, not a physical-flash backup\n", rc, d->pending);
    record(d, "scratch-dirty=%u\n", d->scratch_dirty);
    record(d, "exec-dirty=%u\n", d->exec_dirty);
    record(d, "stage-dirty=%u\n", d->stage_dirty);
    if (d->pending || d->scratch_dirty || d->exec_dirty || d->stage_dirty) {
        __module_get(THIS_MODULE);
        d->pinned = true;
        pci_dev_get(pdev);
        record(d, "REBOOT REQUIRED before unloading/unbinding or reusing controller; DMA retained\n");
    }
    /* Even a negative experiment stays bound until captures are collected. */
    pci_set_drvdata(pdev, d);
    d->directory = debugfs_create_dir("dac960auto", NULL);
    d->result_blob.data = d->result;
    d->result_blob.size = d->used;
    debugfs_create_blob("result.txt", 0400, d->directory, &d->result_blob);
    for (i = 0; i < 54; i++) {
        const char *name = names[i];
        if (flash_map_check && i == 24) name = "fefb0200-a5.bin";
        if (flash_map_check && i == 25) name = "fefb0200-5a.bin";
        if (flash_map_check && i == 26) name = "fefc8200-a5.bin";
        if (flash_map_check && i == 27) name = "fefc8200-5a.bin";
        if (flash_map_check && i == 28) name = "fefe0000-a5.bin";
        if (flash_map_check && i == 29) name = "fefe0000-5a.bin";
        debugfs_create_blob(name, 0400, d->directory, &d->capture[i].blob);
    }
    if (stage_check) {
        static const char * const stage_names[] = {
            "stage-before-a5.bin", "stage-before-5a.bin",
            "stage-candidate-a5.bin", "stage-candidate-5a.bin",
            "stage-restored-a5.bin", "stage-restored-5a.bin",
            "payload-after-a5.bin", "payload-after-5a.bin"
        };
        for (i = 0; i < ARRAY_SIZE(d->stage); i++)
            debugfs_create_blob(stage_names[i], 0400, d->directory, &d->stage[i].blob);
    }
    if(!rc && !d->pinned) {
        d->misc.minor=MISC_DYNAMIC_MINOR;d->misc.name="i960-auto";
        d->misc.fops=&session_fops;d->misc.mode=0600;
        rc=misc_register(&d->misc);
        if(rc) record(d,"misc_register failed=%d\n",rc);
        else d->misc_registered=true;
    }
    return 0;
 free_dma:
    free_captures(d);
    dma_free_coherent(&pdev->dev, DMA_SIZE, d->dma_buf, d->dma);
 unmap:
    pci_iounmap(pdev, d->bar);
 release:
    pci_release_regions(pdev);
 disable:
    pci_disable_device(pdev);
    pci_write_config_word(pdev, PCI_COMMAND, d->saved_command);
 free_state:
    if (d->payload) release_firmware(d->payload);
    kfree(d);
    return rc;
}

static void remove(struct pci_dev *pdev)
{
    struct experiment *d=pci_get_drvdata(pdev);
    if(d->misc_registered) misc_deregister(&d->misc);
    mutex_lock(&d->session_lock);
    if(d->owned && !d->pinned) {session_close(d);session_pin(d);}
    d->removed=true;
    debugfs_remove_recursive(d->directory);
    if(d->pending || d->exec_dirty || d->stage_dirty) {
        session_pin(d);mutex_unlock(&d->session_lock);return;
    }
    writel(d->saved_irq,d->bar+IRQMASK);readl(d->bar+IRQMASK);
    if(d->wad_dma_buf)dma_free_coherent(&pdev->dev,12288,d->wad_dma_buf,d->wad_dma_bus);
    if(d->frame_dma_buf)dma_free_coherent(&pdev->dev,73728,d->frame_dma_buf,d->frame_dma_bus);
    if(d->pp_buf[0])dma_free_coherent(&pdev->dev,73728,d->pp_buf[0],d->pp_bus[0]);
    if(d->pp_buf[1])dma_free_coherent(&pdev->dev,73728,d->pp_buf[1],d->pp_bus[1]);
    if(d->wr_buf[0])dma_free_coherent(&pdev->dev,40960,d->wr_buf[0],d->wr_bus[0]);
    if(d->wr_buf[1])dma_free_coherent(&pdev->dev,40960,d->wr_buf[1],d->wr_bus[1]);
    dma_free_coherent(&pdev->dev,DMA_SIZE,d->dma_buf,d->dma);
    pci_iounmap(pdev,d->bar);pci_release_regions(pdev);pci_disable_device(pdev);
    pci_write_config_word(pdev,PCI_COMMAND,d->saved_command);
    mutex_unlock(&d->session_lock);kref_put(&d->refs,session_free);
}
static struct pci_driver dac960auto_driver = {
    .name = "dac960auto", .id_table = ids, .probe = probe, .remove = remove,
};
static int __init load_init(void)
{
    if (!buffer_io || !firmware_name || !stage_check || !pointer_check || !runtime_check ||
        scratch_check || rom_exec_check || rom_table_check || dram_hook_check || flash_map_check || attempt)
        return -EINVAL;
    return pci_register_driver(&dac960auto_driver);
}
static void __exit load_exit(void) { pci_unregister_driver(&dac960auto_driver); }
module_init(load_init);
module_exit(load_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Controlled DAC960PG Enquiry2/LoadImage capture experiment");
