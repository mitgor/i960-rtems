"""Workload adapter rejects source drift; no Doom-only admission or shutdown."""
from pathlib import Path
import ast,shutil,tempfile
from generate import profile
root=Path(__file__).resolve().parents[3]
paths=['rtems/accele160/doom_dma/'+x for x in ('app.c','frame_dma.h','test_dma.c','build.sh','browser.py','run_bridge.py')]+['game/doom/play/accele160/launch.py']
with tempfile.TemporaryDirectory(prefix='chip8-profile-') as directory:
 out=Path(directory)
 for name in paths:
  dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,dest)
 edits=profile(out);assert len(edits)==len(paths)
 kernel=(out/paths[0]).read_text()
 assert kernel.index('while(live[base]!=live[base+3u])')<kernel.index('first_frame_seen=z;engine_report[5]=z;')
 bridge=(out/paths[-2]).read_text();ast.parse(bridge)
 assert 'wad_query(' not in bridge and 'transact(2,' not in bridge
 assert "write(0xc000e000,0xa4c,struct.pack('<I',0x504f5453))" in bridge
 assert "oracle.check(image)" in bridge and 'complete paired compact DMA/full PIO frame' in bridge
 for name in (paths[-1],'rtems/accele160/doom_dma/browser.py'):ast.parse((out/name).read_text())
 try:profile(out)
 except ValueError:pass
 else:raise AssertionError('profile accepted already transformed sources')
print('PASS exact source generation, host syntax, replay/paired audits, no Doom WAD admission/shutdown, drift rejection')
