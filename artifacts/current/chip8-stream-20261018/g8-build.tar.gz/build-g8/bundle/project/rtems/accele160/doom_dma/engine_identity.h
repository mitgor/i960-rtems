#define ENGINE_ENTRY 0u
#define ENGINE_FILE 135152u
#define ENGINE_SPAN 135152u
#define ENGINE_RESULT 3840u
#define ENGINE_META 135152u
#define ENGINE_SITES 0u
#define ENGINE_TEXT 67u
#define ENGINE_PLAY_OFFSET 4080u
static const unsigned char engine_image_sha[32]={106,184,10,236,84,195,244,156,76,41,199,12,231,228,41,197,183,7,67,250,179,177,93,51,242,119,84,175,231,129,133,77};
static const unsigned char engine_metadata_sha[32]={227,176,196,66,152,252,28,20,154,251,244,200,153,111,185,36,39,174,65,228,100,155,147,76,164,149,153,27,120,82,184,85};
static const unsigned char engine_text_sha[32]={189,197,6,151,4,235,8,96,237,97,170,228,12,33,222,141,68,243,235,210,219,157,22,123,201,106,66,181,20,130,94,161};
static const unsigned engine_geometry[4][4]={{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
#define ENGINE_STARTUP 1
#define ENGINE_PLAYABLE 1
#define ENGINE_PLAY_DOUBLE 1
#define ENGINE_PINGPONG 1
