/home/mit/i960-dma-async-final-host-20261014/residentnet-module/dac960auto.o
