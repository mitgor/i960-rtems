# Card-initiated two-buffer DMA proof

This is an opt-in, finite deterministic producer experiment, not the Doom browser
transport. Hardware results and exact binaries: [acceptance record](../../../artifacts/dma-pingpong-20261015/README.md).

The owning Linux driver allocates two persistent, coherent 73,728-byte buffers.
Each has a 4,096-byte leading guard, 65,536 payload bytes, 4,064 trailing guard
bytes and a 32-byte completion record. Neither userspace nor the renderer may
supply a PCI bus address. The driver registers the two payload addresses once.
No per-frame host DMA start, target status query or metadata read is necessary.
The host still releases each slot explicitly after copying its complete capture.

On the card, the owned engine task prepares a finite chain of two DMA1
descriptors: payload, then completion record. The chain terminates at zero.
The record contains magic, generation, slot, length, card source, start tick,
complemented generation and generation again as the final commit word. The
host checks commit, applies `dma_rmb()`, validates identity and guards, then reads
host RAM. Chaining uses Intel i960Rx Developer Manual 272736-002 §20.3:
six-word descriptors, 32-byte alignment, current descriptor completes before the
next. It does not require a cyclic hardware descriptor list.

Source ownership and destination ownership are separate:

- A card source remains pinned until the DMA channel has completed **and** the
  task has checked the terminal descriptor, disabled DMA and restored isolation.
  The renderer can prepare the other card source while DMA runs.
- A completed host slot remains immutable until its exact generation is released.
  A release arriving before target cleanup is recorded but cannot recycle an
  active destination. Stale and duplicate releases are rejected.
- With both host slots occupied, publication waits. There is no overwrite/drop
  policy. STOP remains independently accessible; active DMA is drained in task
  context before clearing the source. Uncertain hardware completion quarantines
  the session and retains its mappings. A normal reboot releases retained
  exclusive ownership; never force-unload it.
- The ordinary host frame ACK cannot bypass ping-pong ownership after activation.
  ISR control work only registers addresses, records releases and reads small
  status fields. Preparation, polling and checking stay in task context.

The experimental ioctl is `0xc4204d0a`, with the established 1,056-byte fixed
buffer, epoch, zero-reserved words and session lock. Operations: 1 register,
2 host-RAM completion check, 3 host-RAM capture read, 4 exact release,
5 bounded diagnostics, 6 activate, 7 clock sample. Release requires all 72
capture chunks to have been read. Host failures retain mappings. The prototype
runs far below generation wrap and supports one activation per resident session;
it is not a reusable, unbounded streaming ABI.

Build the stress image with `rtems/dma/stress/build_engine.py --pingpong`, then
build the resident kernel with its admission directory, exclusive 12 MiB
ownership, shared heap, atomic dispatch and `--doom-dma`. The admission rejects
Doom and frame-profile combinations for now: the legacy profile timestamps
assume synchronous completion. See the archived build/run scripts for exact
commands and dependency workspace. `live.py --pingpong --frame-dma-stress 80`
runs 16 host-started frames then card-started frames, full system/RAM audits,
five full mailbox comparisons, byte-exact pattern checks on every capture,
stalls with both destinations held, resumption and STOP while stalled.

Validation tools:

- `test_client.py`: complete client orchestration with modeled transport and the
  real command deadline validation; no hardware/performance claim.
- `test_target.py`: actual target C with modeled registers under 32-bit ASan/UBSan;
  active-transfer STOP, bounded timeout quarantine, descriptor mutation and slots.
- `test_host.py`: actual ioctl code, ownership/range/failure injection, no target
  exchange for completion/read, full-read release gate and retained mappings.
- `test_protection.py`: actual protected-page table; old capacity refusal and
  corruption detection in every page of the expanded table.
- `verify.py CAPTURE`: independent replay of both transports, all capture bytes,
  mailbox pairs, release order, STOP and measured intervals.
- `test_replay.py CAPTURE`: corrupt evidence and require rejection.
- `rtems/residentnet/verify.py --root BUILD CAPTURE`: full system/RAM/network
  replay is additionally mandatory. It must not be replaced by frame checks.

Start-to-host-observation latency uses the existing 10 ms card clock with
bracketing host samples; report bounds, not sub-millisecond hardware timing.
Throughput includes guard copies, exact pattern checks, journal writes, slot
releases and periodic full audits. Synthetic producer FPS is not Doom rendering,
HTTP delivery or browser painting FPS. Doom integration requires separate
acceptance including WAD service progress, browser backpressure/disconnect,
input and STOP, and unchanged pixel/palette comparisons.

Doom integration has a concrete additional constraint: `wad_target.h` and the
frame path both program **DMA1** and PCI Command bus-master enable. A renderer
WAD miss during an outstanding frame DMA must first drain that frame transaction
or use an explicitly validated shared-channel scheduler. Calling the current WAD
DMA routine concurrently would correctly fail its idle check. This is why the
new admission is restricted to a zero-WAD-read producer. Do not simply enable its
manifest flag for Doom. The finite runner also retains ordinary Upload command
completion queries; these are separate from the eliminated frame-DMA start and
completion protocol and remain a possible host-overhead optimization.
