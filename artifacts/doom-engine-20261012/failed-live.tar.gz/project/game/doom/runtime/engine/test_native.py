#!/usr/bin/env python3
import argparse,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--build',type=Path,required=True);p.add_argument('--newlib',type=Path,required=True);p.add_argument('--doom',type=Path,required=True);a=p.parse_args();r=Path(__file__).resolve().parent
flags=['-m32','-Os','-funsigned-char','-fno-builtin','-DCMAP256','-D__SINGLE_THREAD__','-I'+str(a.newlib/'newlib/libc/include'),'-I'+str(r.parents[1]/'include'),'-I'+str(a.doom),'-I'+str(r.parent/'platform')]
sanitized=json.loads((a.build/'build.json').read_text()).get('sanitized',False)
if sanitized:flags+=['-fsanitize=address,undefined','-g','-fno-omit-frame-pointer']
objs=[]
for name,src in [('entry',r.parent/'platform/engine_entry.c'),('backend',r.parent/'cache/backend.c'),('native',r/'native.c')]:
 obj=a.build/('owned-'+name+'.o');subprocess.run(['gcc',*flags,'-c',str(src),'-o',str(obj)],check=True);private=obj.with_suffix('.private.o');subprocess.run(['objcopy','--redefine-syms='+str(a.build/'rename.txt'),str(obj),str(private)],check=True);objs.append(private)
for src in [r.parent/'heap.c',r.parents[3]/'loader/segmented/arena.c']:
 obj=a.build/('owned-'+src.stem+'.o');subprocess.run(['gcc',*flags,'-c',str(src),'-o',str(obj)],check=True);objs.append(obj)
exe=a.build/'owned-test';subprocess.run(['gcc','-m32','-no-pie',*map(str,objs),str(a.build/'private-newlib.a'),'-o',str(exe)]+(['-fsanitize=address,undefined'] if sanitized else []),check=True)
for args in [[],['stop'],[]]:subprocess.run([str(exe),*args],check=True)
print('PASS: actual private Newlib owned preflight, 6 MiB zone, frame/palette, WAD backend, local STOP, retired-state refusal and heap drain (32-bit native, not i960 execution)')
