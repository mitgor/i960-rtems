typedef int fixed_t;
typedef struct {int x,y,dx,dy,bbox[2][4];unsigned short children[2];} node_t;
#define FRACBITS 16
extern int FixedMul(int,int);
extern int R_PointOnSide(int,int,node_t*);
struct vector{int x,y;node_t n;};
extern const struct vector vectors[9];
unsigned payload(unsigned arg){const struct vector*v;if(arg>=9)return 0xbad0;v=vectors+arg;return R_PointOnSide(v->x,v->y,(node_t*)&v->n);}
const struct vector vectors[]={{0,-10485760,{117440512,35651584,0,-8388608,{{0}}, {0,0}}},{196608000,-10485760,{117440512,35651584,0,-8388608,{{0}}, {0,0}}},{117440512,-10485760,{117440512,35651584,0,-8388608,{{0}}, {0,0}}},{0,-10485760,{117440512,35651584,0,8388608,{{0}}, {0,0}}},{0,39321600,{135266304,17825792,-8388608,0,{{0}}, {0,0}}},{0,39321600,{135266304,17825792,8388608,0,{{0}}, {0,0}}},{0,6553600,{135266304,17825792,-8388608,0,{{0}}, {0,0}}},{0,6553600,{135266304,17825792,8388608,0,{{0}}, {0,0}}},{0,-10485760,{-146800640,25165824,-4194304,4194304,{{0}}, {0,0}}}};
