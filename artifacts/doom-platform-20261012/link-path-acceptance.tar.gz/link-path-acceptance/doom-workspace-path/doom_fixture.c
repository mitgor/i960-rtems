unsigned protected_fixture(void){return 1;}
