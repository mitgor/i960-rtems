unsigned dummy;unsigned start(void){return 2;}
