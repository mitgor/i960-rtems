# Native fire-key diagnostic

Host-only, no card access. Reuses unchanged sanitized 32-bit Doom/platform
objects from `/home/mit/i960-doom-play-20261013b/platform-host`.
`native.c` instruments the actual engine callback; `helper.c` reads player
state using the pinned engine headers. `reproduce.py` records exact build/run
commands and input paths; it creates a new temporary directory.

Corrected fire key 163 is pressed after frame 30, released after frame 70.
Frame 31 has attack/button set but ammo remains 50. Pistol animation takes
four tics before the firing action: frame 35 first shows ammo 49. At frame
100 the held-fire run has ammo 47; no-input mode retains ammo 50. Both runs
complete STOP210, private retirement, owned heap checks and final drain.

This explains why an accepted press need not immediately change the ammo
counter; it is not a card compiler fault diagnosis. The matching physical
bridge result is documented separately. Binary stderr begins with 100 nine-word
frame records, followed by engine log text. `frames-*.json` decodes those records.
