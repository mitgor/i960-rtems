#include "d_player.h"
extern player_t players[];extern int gametic,key_fire;
void review_row(unsigned*row){row[1]=gametic;row[2]=players[0].ammo[0];row[3]=players[0].attackdown;row[4]=players[0].cmd.buttons;row[5]=players[0].readyweapon;row[6]=players[0].psprites[0].tics;row[7]=players[0].psprites[0].sy;row[8]=key_fire;}
