from pathlib import Path
import subprocess,tempfile,json,struct
w=Path('/home/mit/i960-doom-play-20261013b');b=w/'platform-host';o=Path(tempfile.mkdtemp(prefix='i960-fire-review-'));r=w/'project/game/doom';d=w/'engine-host/doomgeneric-e257a09527062bfb986b6e5e0780839b6cbd5b71/doomgeneric'
s=(b/'play-native.c').read_text();begin=s.index('static int mark(');end=s.index('\n#endif',begin)
s=s[:begin]+'''static int mark(unsigned stage,unsigned x,unsigned y,unsigned z){
 if(stage==100){unsigned row[9];if(y!=65536||z!=frames+1)return 0;
 frames=z;row[0]=frames;review_row(row);syscall(4,2,row,sizeof row);
 if(frames==100){stop=1;return -1;}return 1;}
 if(stage==101){if(mode==6)return 1;if(frames==30&&event_sent==0){event_sent++;return 2+256+163;}if(frames==70&&event_sent==1){event_sent++;return 2+163;}return 1;}
 return 1;
}'''+s[end:]
s='extern void review_row(unsigned*);\n'+s
helper='#include "d_player.h"\nextern player_t players[];extern int gametic,key_fire;\nvoid review_row(unsigned*row){row[1]=gametic;row[2]=players[0].ammo[0];row[3]=players[0].attackdown;row[4]=players[0].cmd.buttons;row[5]=players[0].readyweapon;row[6]=players[0].psprites[0].tics;row[7]=players[0].psprites[0].sy;row[8]=key_fire;}\n'
(o/'helper.c').write_text(helper)
subprocess.run(['gcc','-m32','-funsigned-char','-I'+str(d),'-c',str(o/'helper.c'),'-o',str(o/'helper.o')],check=True)
(o/'native.c').write_text(s)
flags=['-m32','-Os','-fno-builtin','-funsigned-char','-D__SINGLE_THREAD__','-DDOOM_CHECKPOINTS','-DDOOM_VISIBLE','-I'+str(r/'play'),'-I'+str(d),'-I'+str(w/'newlib-1.11.0/newlib/libc/include'),'-fsanitize=address,undefined','-g']
subprocess.run(['gcc',*flags,'-c',str(o/'native.c'),'-o',str(o/'native.o')],check=True)
subprocess.run(['objcopy','--redefine-syms='+str(b/'rename.txt'),str(o/'native.o'),str(o/'private.o')],check=True)
subprocess.run(['gcc','-m32','-no-pie',str(o/'private.o'),str(o/'helper.o'),str(b/'doom-platform.o'),str(b/'play-heap.o'),str(b/'play-arena.o'),'-fsanitize=address,undefined','-o',str(o/'native')],check=True)
for mode in ['0','6']:
 run=subprocess.run([str(o/'native'),'/home/mit/i960-doom-batch-20261012/freedoom1.wad',mode,str(o/f'requests-{mode}.bin'),str(o/f'checkpoints-{mode}.bin')],capture_output=True,timeout=180)
 (o/f'result-{mode}.bin').write_bytes(run.stdout);(o/f'log-{mode}.bin').write_bytes(run.stderr)
 if run.returncode:print(run.stderr[-3000:]);raise SystemExit(run.returncode)
 rows=[dict(zip(['frame','gametic','ammo','attackdown','buttons','weapon','psprite_tics','psprite_sy','key_fire'],struct.unpack_from('<9I',run.stderr,i*36))) for i in range(100)]
 (o/f'frames-{mode}.json').write_text(json.dumps(rows,indent=2))
 print(json.dumps(dict(mode=mode,directory=str(o),sample=[rows[i-1] for i in [1,20,29,30,31,32,35,40,50,60,70,71,80,100]],result=struct.unpack_from('<12I',run.stdout))))
