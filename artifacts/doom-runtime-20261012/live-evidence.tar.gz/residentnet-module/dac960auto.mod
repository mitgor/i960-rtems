/home/mit/i960-doom-runtime-20261012/residentnet-module/dac960auto.o
