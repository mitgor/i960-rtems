static unsigned int runtime_lock(void){return 0;}
static void runtime_unlock(unsigned int v){(void)v;}
