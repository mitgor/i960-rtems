#define R(a) (*(unsigned int*)(unsigned long)(a))
static unsigned int upload_stopping(void){return atomic_load(&halted);}
static unsigned int upload_time(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (unsigned int)(t.tv_sec*100+t.tv_nsec/10000000);}
static void barrier(void){}
static int sync_code(void*p,unsigned int n){return 1;}
#include <execinfo.h>
static void exclusive_abort(void){void *p[32];int n=backtrace(p,32);backtrace_symbols_fd(p,n,2);assert(0);}
unsigned int upload_protect_step(void){return 1;}
unsigned int upload_protect_finish(void){return 1;}
