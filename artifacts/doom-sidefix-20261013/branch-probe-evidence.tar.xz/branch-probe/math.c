int FixedMul(int a,int b){return ((long long)a*(long long)b)>>16;}
