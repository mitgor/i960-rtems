import json,pathlib,struct,subprocess,sys
p=pathlib.Path('/home/mit/i960-doom-sidefix-20261013');b=p/'branch-probe';meta=json.loads((b/'build.json').read_text());rows=[]
for variant in ('unoptimized',):
 for i,expected in enumerate(meta['expected_source_results']):
  out=b/(variant+'-case-'+str(i))
  run=subprocess.run([sys.executable,str(p/'project/host/loadrun/loadrun.py'),str(b/(variant+'.bin')),'--module',str(b/'module/dac960loadrun.ko'),'--argument',str(i),'--output',str(out)],capture_output=True,text=True)
  (b/(variant+'-case-'+str(i)+'.log')).write_text(run.stdout+run.stderr)
  assert run.returncode==0,(variant,i,run.stdout,run.stderr)
  assert (out/'unloaded.txt').exists()
  value=struct.unpack_from('<I',(out/'dram-hook-a5.bin').read_bytes())[0]
  assert value==expected,(i,value,expected)
  rows.append(dict(variant=variant,case=i,expected_source=expected,actual=value,source_match=value==expected,full_loader_audit=True,clean_unload=True))
  (b/'physical-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
print('DONE: all transactions audited and restored; result mismatches remain explicit',flush=True)
