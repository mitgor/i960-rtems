# Exploratory instruction model — NOT acceptance

These temporary variants of repository host/emu.c helped investigate the N3
private-layout difference. They execute the linked i960 0x10000 image, with
added instruction cases, but do not model RTEMS, interrupts, faults, the register
cache, actual I/O, or hardware timing. Allocation is a bounded bump model; frees
are ignored. Runtime time is fixed. setjmp/longjmp are explicitly intercepted
with saved interpreter state. These limitations exclude hardware acceptance,
resource-drain claims and a diagnosis of the first card hang. The added
instruction cases have not received a standalone ISA conformance suite.

The host C interpreter passes ASan/UBSan on these two exploratory paths. That
checks the model's memory use, not the i960 instructions' correctness.

Reproduce each separately (the model writes fixed /tmp/n3-emu-* output paths):

    cc -O2 -fsanitize=address,undefined default.c -o default
    ./default default.elf /path/to/freedoom1.wad
    cc -O2 -fsanitize=address,undefined compat.c -o compat
    ./compat compat.elf /path/to/freedoom1.wad

The default-layout image yielded 4,753 requests, diverging from both the host
and the card at request 4,675. The compatibility-layout image yielded all 4,747
host requests byte-for-byte. Both produced the reference initial-wipe pixel and
palette FNV values. Results and RAM dumps are diagnostic model output, not card
captures. Physical acceptance remains separate and mandatory.
