/home/mit/i960-frame-stress-20261014/residentnet-module/dac960auto.o
