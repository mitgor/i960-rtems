/home/mit/i960-framequeue-20261011-6UXJme/module-base/dac960rtems.o
