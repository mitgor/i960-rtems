#define WORKER_ITERATIONS 1000
#define I960_HEAP_SHARED 1
#define I960_QUEUE_RECLAIM 1
#define I960_GENERAL_HEAP 1
#define I960_HEAP_TEST 0
#define HEAP_NATIVE 1
#include "general_heap.c"
unsigned int _ISR_Nest_level;
void resident_net_irq_counts(unsigned int*w){w[0]=w[1]=0;}
void*memset(void*p,int c,size_t n){unsigned char*q=p;while(n--)*q++=c;return p;}
void*memcpy(void*p,const void*q,size_t n){unsigned char*d=p;const unsigned char*s=q;while(n--)*d++=*s++;return p;}
static void quit(unsigned int code){__asm__ volatile("int $0x80"::"a"(1),"b"(code):"memory");for(;;){}}
#define CHECK(x) do{if(!(x))quit(__LINE__);}while(0)

#include "../exclusive/worker_stop.h"
static void stop_other(void){
 native_actor=0;
#ifdef STOP_BARRIER
 CHECK(!worker_stop_arrive(0));
#else
 resident_heap_drain(0);
#endif
 native_actor=1;
}
void _start(void){
 if(__builtin_setjmp(native_jump)){
#ifndef STOP_BARRIER
  CHECK(heap_error==10&&allocations==frees&&!live_bytes);quit(0);
#else
  quit(99);
#endif
 }
 CHECK(!worker_stop_complete());
 CHECK(!worker_stop_expired(100,1099,99999999u));CHECK(worker_stop_expired(100,1100,0));
 CHECK(worker_stop_expired(100,100,100000000u));CHECK(worker_stop_expired(0xfffffff0u,984,0));
 CHECK(!resident_heap_init());native_actor=0;shared_worker(0,1);CHECK(shared_phase==1);
 native_actor=1;native_preempt=stop_other;
 /* Preempt immediately before the actual acquire takes its heap lock. */
 shared_worker(1,2);
#ifdef STOP_BARRIER
 CHECK(worker_stop_arrive(1));native_actor=0;resident_heap_drain(0);
 native_actor=1;resident_heap_drain(1);CHECK(!heap_error&&resident_heap_valid()&&!live_bytes&&allocations==frees&&shared_created==shared_retired);quit(0);
#else
 quit(98); /* the old code must reproduce SHCHECK 10 */
#endif
}
