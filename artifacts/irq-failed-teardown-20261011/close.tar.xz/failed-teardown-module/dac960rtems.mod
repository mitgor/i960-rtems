/home/mit/i960-rtems-web-20261011/failed-teardown-module/dac960rtems.o
