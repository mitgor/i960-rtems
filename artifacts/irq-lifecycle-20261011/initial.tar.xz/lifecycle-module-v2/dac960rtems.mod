/home/mit/i960-rtems-web-20261011/lifecycle-module-v2/dac960rtems.o
