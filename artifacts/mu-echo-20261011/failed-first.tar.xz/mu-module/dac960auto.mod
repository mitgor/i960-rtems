/home/mit/i960-rtems-web-20261011/mu-module/dac960auto.o
