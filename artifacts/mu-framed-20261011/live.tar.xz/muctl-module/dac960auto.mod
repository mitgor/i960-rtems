/home/mit/i960-rtems-web-20261011/muctl-module/dac960auto.o
