/home/mit/i960-rtems-web-20261011/muctx-module/dac960auto.o
