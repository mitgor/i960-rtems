/home/mit/i960-point-side-20261016/probe/module/dac960loadrun.o
