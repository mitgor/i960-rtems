/home/mit/i960-ray-20261011-AesT6N/module/dac960rtems.o
