#ifndef I960_LWIP_CC_H
#define I960_LWIP_CC_H
#include <stddef.h>
typedef unsigned char u8_t;
typedef signed char s8_t;
typedef unsigned short u16_t;
typedef signed short s16_t;
typedef unsigned int u32_t;
typedef signed int s32_t;
typedef unsigned long long u64_t;
typedef signed long long s64_t;
typedef unsigned int mem_ptr_t;
#define BYTE_ORDER LITTLE_ENDIAN
#define LWIP_PLATFORM_DIAG(x) do {} while(0)
void bounded_fatal(unsigned int code);
#define LWIP_PLATFORM_ASSERT(x) bounded_fatal(0x60000+__LINE__)
#define PACK_STRUCT_STRUCT __attribute__((packed))
#define PACK_STRUCT_BEGIN
#define PACK_STRUCT_END
#define PACK_STRUCT_FIELD(x) x
#endif
