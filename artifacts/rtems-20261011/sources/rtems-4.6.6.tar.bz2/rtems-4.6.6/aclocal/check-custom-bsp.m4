dnl $Id: check-custom-bsp.m4,v 1.1.2.1 2004/08/18 07:23:00 ralf Exp $

AC_DEFUN([RTEMS_CHECK_CUSTOM_BSP],[
AC_REQUIRE([RTEMS_TOP])

AC_MSG_CHECKING([for make/custom/[$]$1.cfg])
AS_IF([test -r "$srcdir/$RTEMS_TOPdir/make/custom/[$]$1.cfg"],
  [AC_MSG_RESULT([yes])],
  [AC_MSG_ERROR([no])])
])
