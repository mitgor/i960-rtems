dnl $Id: enable-multiprocessing.m4,v 1.6.2.1 2004/08/18 07:23:00 ralf Exp $

AC_DEFUN([RTEMS_ENABLE_MULTIPROCESSING],
[
AC_ARG_ENABLE(multiprocessing,
[AC_HELP_STRING([--enable-multiprocessing],
[enable multiprocessing interface])],
[case "${enable_multiprocessing}" in 
  yes) ;;
  no) ;;
  *)  AC_MSG_ERROR(bad value ${enableval} for enable-multiprocessing option) ;;
esac],[enable_multiprocessing=no])
])
