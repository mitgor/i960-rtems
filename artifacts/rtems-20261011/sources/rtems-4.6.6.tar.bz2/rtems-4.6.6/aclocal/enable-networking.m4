dnl $Id: enable-networking.m4,v 1.7.2.1 2004/08/18 07:23:00 ralf Exp $

AC_DEFUN([RTEMS_ENABLE_NETWORKING],
[
## AC_BEFORE([$0], [RTEMS_CHECK_NETWORKING])dnl

AC_ARG_ENABLE(networking,
[AC_HELP_STRING([--enable-networking],[enable TCP/IP stack])],
[case "${enableval}" in
  yes) RTEMS_HAS_NETWORKING=yes ;;
  no) RTEMS_HAS_NETWORKING=no ;;
  *)  AC_MSG_ERROR(bad value ${enableval} for enable-networking option) ;;
esac],[RTEMS_HAS_NETWORKING=yes])
AC_SUBST(RTEMS_HAS_NETWORKING)dnl
])
