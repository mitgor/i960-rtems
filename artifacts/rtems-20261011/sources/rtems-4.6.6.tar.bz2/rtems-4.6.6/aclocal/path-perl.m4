dnl $Id: path-perl.m4,v 1.3.6.1 2004/08/18 07:23:00 ralf Exp $

AC_DEFUN([RTEMS_PATH_PERL],
[
AC_PATH_PROG(PERL,perl)
if test -z "$PERL" ; then
AC_MSG_WARN(
[***]
[   perl was not found]
[   Note: Some tools will not be built.])
fi
])
