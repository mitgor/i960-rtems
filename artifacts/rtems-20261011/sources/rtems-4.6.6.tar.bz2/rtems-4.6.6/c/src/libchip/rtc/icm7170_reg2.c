/*
 *  This file contains a typical set of register access routines which may be
 *  used with the icm7170 chip if accesses to the chip are as follows:
 *
 *    + registers are accessed as bytes
 *    + registers are on 16-bit boundaries
 *
 *  COPYRIGHT (c) 1989-1997.
 *  On-Line Applications Research Corporation (OAR).
 *
 *  The license and distribution terms for this file may be
 *  found in the file LICENSE in this distribution or at
 *  http://www.rtems.com/license/LICENSE.
 *
 *  $Id: icm7170_reg2.c,v 1.2.6.1 2003/09/04 18:46:04 joel Exp $
 */

#define _ICM7170_MULTIPLIER 2
#define _ICM7170_NAME(_X) _X##_2
#define _ICM7170_TYPE unsigned8

#include "icm7170_reg.c"

