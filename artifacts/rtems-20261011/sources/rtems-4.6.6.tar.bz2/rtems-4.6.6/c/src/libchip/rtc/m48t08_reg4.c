/*
 *  This file contains a typical set of register access routines which may be
 *  used with the m48t08 chip if accesses to the chip are as follows:
 *
 *    + registers are accessed as bytes
 *    + registers are on 32-bit boundaries
 *
 *  COPYRIGHT (c) 1989-1997.
 *  On-Line Applications Research Corporation (OAR).
 *
 *  The license and distribution terms for this file may be
 *  found in the file LICENSE in this distribution or at
 *  http://www.rtems.com/license/LICENSE.
 *
 *  $Id: m48t08_reg4.c,v 1.2.6.1 2003/09/04 18:46:04 joel Exp $
 */

#define _M48T08_MULTIPLIER 4
#define _M48T08_NAME(_X) _X##_4
#define _M48T08_TYPE unsigned8

#include "m48t08_reg.c"

