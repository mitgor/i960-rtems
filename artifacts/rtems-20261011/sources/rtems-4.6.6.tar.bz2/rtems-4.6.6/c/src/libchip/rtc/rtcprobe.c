/*
 *  This file contains the default Real-Time Clock probe routine.
 *
 *  COPYRIGHT (c) 1989-1999.
 *  On-Line Applications Research Corporation (OAR).
 *
 *  The license and distribution terms for this file may be
 *  found in the file LICENSE in this distribution or at
 *  http://www.rtems.com/license/LICENSE.
 *
 *  $Id: rtcprobe.c,v 1.2.8.1 2003/09/04 18:46:04 joel Exp $
 */

#include <rtems.h>
#include <libchip/rtc.h>


boolean rtc_probe(
  int minor
)
{
  return TRUE;
}
