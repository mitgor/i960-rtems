/*
 *  $Id: serprobe.c,v 1.2 2001/03/14 19:42:49 joel Exp $
 */

#include <rtems.h>
#include <libchip/serial.h>
#include <libchip/sersupp.h>

boolean libchip_serial_default_probe(int minor)
{
  /*
   * If the configuration dependent probe has located the device then
   * assume it is there
   */

  return TRUE;
}



