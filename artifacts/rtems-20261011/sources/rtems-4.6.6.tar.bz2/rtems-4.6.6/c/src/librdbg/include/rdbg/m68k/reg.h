/*
 * Registers frame offset definition
 *
 * $Id: reg.h,v 1.1 2000/10/19 15:35:21 joel Exp $
 */

#define NBREGS	18

typedef unsigned int regs[NBREGS];

/* To be used in common code */
typedef regs REGS;

