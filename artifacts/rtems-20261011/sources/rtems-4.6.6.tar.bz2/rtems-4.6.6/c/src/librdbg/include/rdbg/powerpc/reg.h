/*
 * Registers frame offset definition
 *
 * $Id: reg.h,v 1.1 1999/08/10 16:41:10 joel Exp $
 */

#define NBREGS	43

typedef unsigned int regs[NBREGS];

/* To be used in common code */
typedef regs REGS;




