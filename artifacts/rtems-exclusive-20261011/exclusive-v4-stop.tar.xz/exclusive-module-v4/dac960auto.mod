/home/mit/i960-rtems-web-20261011/exclusive-module-v4/dac960auto.o
