/home/mit/i960-rtems-web-20261011/residentnet-module-fault-net/dac960auto.o
