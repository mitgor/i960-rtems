/home/mit/i960-rtems-web-20261011/residentnet-module-nmi/dac960auto.o
