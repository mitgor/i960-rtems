# Exclusive exception ownership — work in progress, 2026-10-11

This is an opt-in, reboot-only extension of held secondary reset. Compile with
`--profile residentnet --secondary-reset --fault-owner`. Default and cooperative
profiles keep their previous behavior. No flash changes are made.

## Architecture and boundaries

Intel 272736-002 sections 8.2.3, 9.3–9.5 and 11.4.2 describe the cached NMI
vector, two-word fault entries, hardware records and PRCB. The existing live
PRCB is `feffd4d0`, pointing to fault table `c0000800`. We replace the 32
entries with local-call handlers and zero reserved words; we do not relocate
the PRCB. Cached NMI vector address zero and the interrupt-stack register also
become owned. Each is read back. The handlers do not return to stock firmware.

The terminal entry records the hardware frame and transfers C execution to a
separate 4 KiB guarded area. It masks hardware interrupts, stops scheduling,
and serves only snapshot/read/STOP acknowledgements through the existing
message channel. STOP acknowledges an already terminal state; it does not
release reset, restart tasks or free resources. A second exception during
terminal handling parks without calling C again. This is containment, not
fault recovery or continuation. A destroyed current stack can prevent the
processor from delivering a fault before our handler gains control; the new
stack does not remove that architectural limitation.

The owned-exception profile uses 68 packet slots, reserving space for its new
stack and record within the existing allocation. Other resident builds retain
72 slots. A queue-capacity reduction is explicitly recorded, not presented as
an increase in usable RAM. `RNT4` distinguishes this layout; snapshot bit 2
rechecks vector/table/stack ownership and guards.

## Physical evidence so far

The first image passed a 100-tick bounded probe, 33 firmware callbacks, exact
restoration and module unload. Its resident test deliberately executed `faulte`
after 100 timer ticks. The terminal capture contains type/subtype `00050001`,
IP `c0f2e930`, stable diagnostics, held SCSI reset, intact guards and no firmware
callback after ARM. The paired captures, pinned image/module and host control
transactions pass independent replay. Resources were retained at close.

**Physical NMI delivery has not been tested.** The architecture prohibits
software-posting vector 248. `--fault-test 2` will call a synthetic entry with
kind 3, distinct from hardware NMI kind 2 and real fault kind 1. It can test
terminal plumbing but cannot prove hardware NMI delivery.

The first image installed exception ownership after reset. The next source
revision installs it before reset, after phase-2 isolation, to close a possible
stock-NMI reinitialization window. This revision requires its own card tests;
the earlier capture must not be used as proof of the revised ordering.

## RAM investigation

No new RAM is currently granted. `ram_probe.h` is an offline-tested destructive
256 KiB candidate-range algorithm, not called by live code. It checks four
address-dependent patterns, aliased address lines, corrupt data and a caller's
boundary predicate. Before wiring it into a target experiment, validate the
revised exception ownership, audit surviving CPU/interrupt/monitor dependencies,
preserve neighboring bytes, and define cache coherency checks. Passing this
algorithm alone cannot authorize an allocator or prove all 16 MiB usable.

See [batch artifacts](../../artifacts/rtems-fault-ownership-20261011/README.md).
Manual source: https://datasheets.chipdb.org/Intel/80960/manuals/27273602.PDF
