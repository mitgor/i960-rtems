/home/mit/i960-rtems-web-20261011/residentnet-module-fault-ram/dac960auto.o
