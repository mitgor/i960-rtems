/home/mit/i960-rtems-web-20261011/residentnet-module-fault1/dac960auto.o
