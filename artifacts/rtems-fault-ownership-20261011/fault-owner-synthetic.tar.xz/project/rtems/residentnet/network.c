#ifdef I960_FAULT_OWNER
#define NETWORK_QUEUE_SLOTS 68
#else
#define NETWORK_QUEUE_SLOTS 72
#endif
#define NETWORK_FRAME_BYTES 1500
#define RESIDENT_QUEUE_STATS 1
#include "../net/network.c"
