/home/mit/i960-rtems-web-20261011/residentnet-module-fault2/dac960auto.o
