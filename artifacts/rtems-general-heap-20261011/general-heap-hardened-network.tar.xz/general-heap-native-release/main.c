#define I960_GENERAL_HEAP 1
#define I960_HEAP_TEST 0
#define HEAP_NATIVE 1
#include "general_heap.c"
unsigned int _ISR_Nest_level;
void*memset(void*p,int c,size_t n){unsigned char*q=p;while(n--)*q++=c;return p;}
void*memcpy(void*p,const void*q,size_t n){unsigned char*d=p;const unsigned char*s=q;while(n--)*d++=*s++;return p;}
static void quit(unsigned int code){__asm__ volatile("int $0x80"::"a"(1),"b"(code):"memory");for(;;){}}
#define CHECK(x) do{if(!(x))quit(__LINE__);}while(0)
void _start(void){unsigned int i,t,old;unsigned char*p;void*saved;void*slots[64];
 CHECK(sizeof(void*)==4);CHECK(!resident_malloc(1));CHECK(!resident_heap_init());CHECK(resident_heap_valid()&&selftest);
 p=resident_malloc(RESIDENT_HEAP_BYTES-64);CHECK(p&&resident_heap_valid());
 CHECK(!resident_malloc(1));CHECK(!resident_free(p)&&resident_heap_valid());
 for(i=0;i<64;i++){slots[i]=resident_malloc(1);CHECK(slots[i]&&!((unsigned int)slots[i]&15));}
 CHECK(!resident_malloc(1));CHECK(!resident_realloc(slots[0],2));
 for(i=0;i<64;i++)CHECK(!resident_free(slots[i]));
 p=resident_realloc(0,100);CHECK(p);memset(p,0x71,100);
 p=resident_realloc(p,20);CHECK(p);for(i=0;i<20;i++)CHECK(p[i]==0x71);
 CHECK(!resident_realloc(p,0)&&!resident_free(0));
 for(t=1;t<=1000;t++){resident_heap_step(0,t);resident_heap_step(1,t);}
 resident_heap_drain(0);resident_heap_drain(1);CHECK(!live_bytes&&allocations==frees&&resident_heap_valid());
 _ISR_Nest_level=1;CHECK(!resident_malloc(64)&&native_mask==0);_ISR_Nest_level=0;
 p=resident_malloc(100);CHECK(p);old=frees;
 for(i=0;i<32;i++){
  unsigned char*q=i<16?p-16+i:p+100+i-16;*q^=1;
  if(!__builtin_setjmp(native_jump)){resident_malloc(1);quit(200);}
  CHECK(heap_error==3&&frees==old);*q^=1;heap_error=0;native_mask=0;
 }
 for(i=0;i<32;i++){
  unsigned int*q=(unsigned int*)(p-20);*q^=1u<<i;
  if(!__builtin_setjmp(native_jump)){resident_free(p);quit(203);}
  CHECK(heap_error==2&&frees==old);*q^=1u<<i;heap_error=0;native_mask=0;
 }
 saved=app_heap.first;
 for(i=0;i<32;i++){
  app_heap.first=(void*)((unsigned int)saved^(1u<<i));
  if(!__builtin_setjmp(native_jump)){resident_malloc(1);quit(201);}
  CHECK(heap_error==2&&frees==old);app_heap.first=saved;heap_error=0;native_mask=0;
 }
 native_admit=0;
 if(!__builtin_setjmp(native_jump)){resident_malloc(1);quit(202);}
 CHECK(heap_error==1&&frees==old);native_admit=1;heap_error=0;native_mask=0;
 CHECK(!resident_free(p)&&!live_bytes&&allocations==frees&&resident_heap_valid());
 slots[0]=resident_malloc(100);slots[1]=resident_malloc(100);slots[2]=resident_malloc(100);
 CHECK(slots[0]&&slots[1]&&slots[2]);CHECK(!resident_free(slots[0])&&!resident_free(slots[2]));
 saved=app_heap.first->next;app_heap.first->next=0;old=frees;
 if(!__builtin_setjmp(native_jump)){resident_free(slots[1]);quit(204);}
 CHECK(heap_error==2&&frees==old);app_heap.first->next=saved;heap_error=0;native_mask=0;
 CHECK(!resident_free(slots[1])&&!live_bytes&&allocations==frees&&resident_heap_valid());
 quit(0);
}
