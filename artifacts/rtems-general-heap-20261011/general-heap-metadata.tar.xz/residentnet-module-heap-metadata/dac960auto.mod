/home/mit/i960-rtems-web-20261011/residentnet-module-heap-metadata/dac960auto.o
