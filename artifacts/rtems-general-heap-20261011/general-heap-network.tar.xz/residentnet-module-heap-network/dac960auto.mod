/home/mit/i960-rtems-web-20261011/residentnet-module-heap-network/dac960auto.o
