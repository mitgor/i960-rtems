/home/mit/i960-rtems-web-20261011/autonet-module-system-info/dac960auto.o
