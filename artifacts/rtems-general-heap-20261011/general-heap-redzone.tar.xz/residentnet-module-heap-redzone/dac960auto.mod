/home/mit/i960-rtems-web-20261011/residentnet-module-heap-redzone/dac960auto.o
