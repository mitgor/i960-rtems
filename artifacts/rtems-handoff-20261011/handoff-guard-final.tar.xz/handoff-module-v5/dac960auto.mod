/home/mit/i960-rtems-web-20261011/handoff-module-v5/dac960auto.o
