/home/mit/i960-rtems-web-20261011/handoff-module-v3/dac960auto.o
