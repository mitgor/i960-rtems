/* Evidence bits are target-owned proof, never host claims or idle snapshots. */
#define TRANSFER_REQUIRED 0x7fu
#define TRANSFER_DENIED 1u
#define TRANSFER_BUSY 2u
static unsigned int transfer_check(unsigned int proof,unsigned int busy,unsigned int drift){
 if(busy||drift)return TRANSFER_BUSY;
 return (proof&TRANSFER_REQUIRED)==TRANSFER_REQUIRED?0:TRANSFER_DENIED;
}
