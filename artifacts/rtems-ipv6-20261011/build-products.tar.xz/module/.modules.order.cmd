savedcmd_/home/mit/i960-rtems-ipv6-20261011/module/modules.order := {   echo /home/mit/i960-rtems-ipv6-20261011/module/dac960rtems.o; :; } > /home/mit/i960-rtems-ipv6-20261011/module/modules.order
