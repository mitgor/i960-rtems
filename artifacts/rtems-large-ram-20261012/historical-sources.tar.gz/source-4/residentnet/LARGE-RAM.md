# Exclusive RAM, kernel workspace and task stacks

Implementation and acceptance work started 2026-10-12. See the dated artifact
report for physical results; compilation alone grants no RAM.

`--owned-mib {1,4,10,12}` requires the release residentnet profile with
`--secondary-reset --fault-owner --extra-ram --general-heap --heap-shared
--queue-reclaim`. Default/cooperative profiles remain available and unchanged.
This is reboot-only exclusive takeover. No flash changes are required.

## Admission and layout

The fixed candidate begins at `c0240000`, immediately above the existing tested
256 KiB region. Sizes end at `c0340000`, `c0640000`, `c0c40000`, or `c0e40000`.
The maximum ends below the original upload/monitor at `c0f2c000` and below cache
descriptors at `c0fe8000`. These addresses belong to stock cache data until takeover.

The original ARM callback now defers RTEMS initialization for this profile.
After it returns, the monitor acquires engine isolation, installs owned fault/NMI
paths and holds secondary SCSI reset. The large-memory admission then checks the
exact board/ROM dispatch/staging identity, disabled DMA state, empty software
interrupt table and no overlap with the parked original frame plus 64 KiB margin.
It disables data cache and runs four full address-dependent write/read passes.
After every pass it compares hashes of low RAM and the region from the candidate
end through the immutable upload code. These detect unintended writes to those
protected intervals, with the usual collision limitation of a 32-bit hash.
Runtime mutable upload RAM is excluded because the test itself modifies state there.

Only after successful admission may RTEMS initialize its external workspace and
stacks. The existing external queue/application heap are then admitted separately.
An error retains the exclusive machine state; it never resumes stock firmware.

| Region | Purpose |
| --- | --- |
| `c0240000..c0240040` | Lower guard |
| `c0240040..c0280040` | 256 KiB RTEMS kernel workspace |
| `c0280040..c0280080` | Workspace/stack boundary guard |
| `c0280080..c02c0280` | Four stack slots, each 64 KiB plus 128 bytes |
| `c02c0280..c02d0000` | Reserved separation; not allocated |
| `c02d0000..candidate_end-64` | Pattern-filled reserve, not yet an application heap |
| `candidate_end-64..candidate_end` | Upper guard |

The Init and two worker tasks request 64 KiB each. The idle task retains its
small RTEMS request within a reserved 64 KiB-capacity slot. Two separate 8 KiB
owned interrupt stacks and the terminal fault stack remain in the original
upload allocation. Workspace increases from 48 to 256 KiB; application heap
remains 171,824 bytes. No executable/upload window is enlarged by this change.

Both workers preserve and periodically check a live 12 KiB stack object across
interrupt-driven execution. Shutdown checks the stack guards and unused tails.
The reserve is sampled every 64 KiB during heap/ownership validation; after tasks
and ISR contexts drain, every reserve word is checked before publishing parked
state. Sparse runtime checks do not detect every transient or unsampled write.

## Control and endurance

The image-pinned large-memory host module uses 50–100 us polling for resident
control replies instead of 1–1.5 ms. Timeout remains bounded by a 20-second wall
clock; initial takeover permits 180 seconds for full RAM testing. Packet polling,
sequence validation, poisoning on uncertainty and resource retention remain.
This changes host reply-detection latency, not the 100 Hz scheduling period.

RAM diagnostic page 2 reports the candidate, passes, word count, error/address,
workspace/stack layout, reserve checks, original frame and actual stack requests.
The large profile permits up to 360,000 ticks (one hour); ordinary residentnet
keeps its existing 180,000-tick maximum. Each test still has an explicit deadline.

## Remaining ownership work

Even a successful 12 MiB test is not an 11+ MiB malloc arena. Next add a guarded
allocator arena to the reserve, replace its immutable-pattern contract with
allocation/reference ownership, and test large allocations, sharing, cancellation,
fragmentation and failure retention. Then provide a segmented loader for larger
code/data, independently of RTEMS kernel workspace. See the
[Doom OS plan](../../game/doom/OS-PLAN.md).
