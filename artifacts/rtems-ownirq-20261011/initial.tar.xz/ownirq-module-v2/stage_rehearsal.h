/* Exact pinned one-shot target. QUIESCED alone never authorizes reclamation. */
static int ownirq_evidence_valid(const unsigned int*w,unsigned int epoch,unsigned int mode){unsigned int i,j;const unsigned int*c=w+60;
 if(w[0]!=0x3149524f||w[1]!=1||w[2]||w[3]!=mode||mode<1||mode>5||w[4]!=epoch||!epoch||epoch>65535)return 0;
 if(w[5]<20||w[5]>100||w[6]<2||w[7]<4||!w[8]||w[9]<w[8]||w[10]!=w[9]||w[16]!=10000)return 0;
 if(w[17]||w[18]!=0x10c7||w[19]!=0x80000||w[20]!=w[21]||w[22]||w[23]||w[24]||(w[25]&0x2000)||w[26]||w[27]||w[31])return 0;
 if(w[32]!=2||w[34]!=2||w[35]!=1||w[40]!=epoch||w[45]!=1||w[46]!=1||w[50]||w[51]!=1||w[53]!=1||w[54]!=23)return 0;
 if(!w[14]||!w[15]||w[15]>=w[14]||w[14]>1000000||!w[244]||!w[245]||!w[246]||w[244]==w[245]||w[244]==w[246]||w[245]==w[246])return 0;
 if(!w[247]||w[247]!=w[248]||w[250]!=1||w[252]||!w[253]||w[254]!=0x4d554f4b||w[255]!=0x514f4b31)return 0;
 if(mode<=2){
  if(w[11]<=w[10]||w[12]<w[11]||w[13]||w[28]||w[29]||w[30]||w[33]!=2||w[36]!=1||w[37]!=0x10203040||w[38]!=1||!w[39])return 0;
  if(w[41]!=3||w[42]!=0x55667788||w[43]!=w[42]||w[44]||w[47]!=1||w[48]!=3||w[49]!=1||w[52]!=1||w[249]||w[251]!=1)return 0;
 }else{
  if(w[12]||w[13]!=w[9]+4||w[28]!=w[244]||w[29]!=1||w[30]!=1||w[33]!=0x402||w[36]||w[37]||w[38]||w[39])return 0;
  if(w[41]!=4||w[42]!=0x10203040||w[43]!=0xdeadbeef||w[44]!=(mode==5)||w[47]||w[48]!=(mode==5?4:5)||w[49]||w[249]!=1||w[251])return 0;
  if(mode==5){if(w[11]||w[52])return 0;}else if(w[11]!=w[13]||w[52]!=1)return 0;
  if(!w[55]||w[55]>1000000||!w[56]||w[56]!=w[57]||!w[58]||w[58]!=w[59]||!c[18]||c[18]!=c[19])return 0;
 }
 if(mode<=2||mode==4){
  if(c[0]!=mode||c[1]<16||c[2]!=c[1]+12||c[3]!=c[2]+12||c[4]<c[3]||c[5]!=2||c[6]!=1||c[7]!=1||c[8]||c[9]!=c[10]||c[11]!=c[3]||c[12]||c[13]!=12||c[14]!=12||c[15]||c[16]<20||c[17]!=(mode==2?2:1)||w[9]!=c[3])return 0;
  if(mode==2){if(w[8]<c[2]+1||w[8]>=c[3])return 0;}else if(w[8]<c[1]+1||w[8]>=c[2])return 0;
 }else if(w[8]<16||w[9]!=w[8])return 0;
 for(i=0;i<2;i++){const unsigned int*s=w+80+i*82,*r=s+12;unsigned int live=(i==1||mode>=3);
  if(!s[0]||s[2]-s[1]!=8192||s[3]<s[1]+16||s[3]>s[2]-64||(s[3]&15)||s[6]!=0xf2||s[7]!=live||s[8]!=s[9]+live||s[8]<2||s[11]<s[10]+192||s[11]>=s[10]+8128)return 0;
  for(j=0;j<15;j++)if(r[j]!=0x19600000u+i*0x10000000u+j)return 0;
  if(r[68]||!r[69]||r[69]>1000000)return 0;
  if(!live){for(j=0;j<16;j++)if(r[j]!=r[j+16])return 0;
   for(j=0;j<16;j++)if(j!=2&&j!=3&&j!=5&&r[32+j]!=r[48+j])return 0;
   if(r[64]!=r[65]||r[66]!=r[67])return 0;}
 }
 if(w[80]==w[162]||w[90]==w[172]||(mode>=3&&w[161]!=w[55])||w[243]!=w[15])return 0;
 return 1;
}
static int ownirq_report_valid(const unsigned int*w,unsigned int epoch,unsigned int mode){return ownirq_evidence_valid(w,epoch,mode)&&!w[44];}

/* Included after issue(): fixed no-program staging transaction.
 * Every write attempt sets dirty BEFORE submission. A known-complete error
 * enters restoration; uncertain completion stops all commands and pins DMA.
 */
static int stage_hash(struct experiment *d, const u8 *data,
                      const u8 *expected, const char *label)
{
    struct crypto_shash *tfm;
    struct shash_desc *desc;
    u8 digest[32];
    int rc;
    tfm = crypto_alloc_shash("sha256", 0, 0);
    if (IS_ERR(tfm)) return PTR_ERR(tfm);
    desc = kzalloc(sizeof(*desc) + crypto_shash_descsize(tfm), GFP_KERNEL);
    if (!desc) { crypto_free_shash(tfm); return -ENOMEM; }
    desc->tfm = tfm;
    rc = crypto_shash_digest(desc, data, IMAGE_WINDOW, digest);
    if (!rc) {
        record(d, "stage %s sha256=%*phN\n", label, 32, digest);
        if (memcmp(digest, expected, 32)) rc = -ENODATA;
    }
    kfree(desc);
    crypto_free_shash(tfm);
    return rc;
}

static int stage_read_pair(struct experiment *d, unsigned int slot,
                           const u8 *hash, const char *label)
{
    unsigned int off, pass;
    int rc;
    for (pass = 0; pass < 2; pass++) {
        for (off = 0; off < IMAGE_WINDOW; off += MAX_READ) {
            u16 count = min_t(u32, MAX_READ, IMAGE_WINDOW - off);
            rc = issue(d, 0x20, count, off, pass ? 0x5a : 0xa5,
                       ARRAY_SIZE(d->capture));
            if (rc) return rc;
            memcpy(d->stage[slot + pass].data + off, d->dma_buf, count);
        }
    }
    if (memcmp(d->stage[slot].data, d->stage[slot + 1].data, IMAGE_WINDOW))
        return -ENODATA;
    rc = stage_hash(d, d->stage[slot].data, hash, label);
    if (!rc) record(d, "VERIFIED stage %s: paired 524288-byte reads and pinned SHA256\n", label);
    return rc;
}

/* Included after stage read/hash helpers. Only uses existing stock 20/21 and
 * temporary returning 6F callbacks. Never invokes flash commands. */
static int load_digest(const void *data, unsigned int size, u8 digest[32])
{
    struct crypto_shash *tfm = crypto_alloc_shash("sha256",0,0);
    struct shash_desc *desc;
    int rc;
    if (IS_ERR(tfm)) return PTR_ERR(tfm);
    desc = kzalloc(sizeof(*desc)+crypto_shash_descsize(tfm),GFP_KERNEL);
    if (!desc) { crypto_free_shash(tfm); return -ENOMEM; }
    desc->tfm=tfm;
    rc=crypto_shash_digest(desc,data,size,digest);
    kfree(desc);crypto_free_shash(tfm);return rc;
}
static int load_chunks(struct experiment *d,const u8 *data)
{
    u32 off;
    int rc;
    for(off=0;off<d->payload->size;off+=MAX_READ) {
        u16 count=min_t(u32,MAX_READ,d->payload->size-off);
        d->upload_data=data+off;
        rc=issue(d,0x21,count,off,0xa5,ARRAY_SIZE(d->capture));
        d->upload_data=NULL;
        if(rc) return rc;
    }
    return 0;
}
static int load_expect(struct experiment *d,u16 expected)
{
    unsigned int i;
    int rc;
    for(i=0;i<4;i++) {
        d->exec_expected_status=0xffff;
        rc=issue(d,0x6f,0,0,0xa5,34);
        if(rc) return rc;
        if(d->exec_last_status==expected) return 0;
        /* Only harmless ROM PING / cache-control callbacks can repeat here.
         * Never used while the executable runner could remain installed. */
        if(d->exec_last_status!=0x017e && d->exec_last_status!=0x017d) return -ENODATA;
        rc=issue(d,0x1c,0,0,0x5a,3);
        if(rc) return rc;
        msleep(20);
    }
    return -ENODATA;
}
static int load_code(struct experiment *d,const u8 *code,u32 offset,u16 size,
                     unsigned int upload_slot,unsigned int read_slot)
{
    int rc=exec_upload(d,code,size,offset,upload_slot);
    if(!rc) rc=read_pair(d,STAGING_BASE+offset,EXEC_REGION_SIZE,read_slot);
    if(!rc && memcmp(code,d->capture[read_slot].data,size)) rc=-ENODATA;
    return rc;
}
static int load_table(struct experiment *d,const u8 *pointer,unsigned int slot)
{
    int rc=exec_upload(d,pointer,4,EXEC_TABLE_OFFSET,31);
    if(!rc) rc=read_pair(d,EXEC_TABLE_ADDRESS,4,slot);
    if(!rc && memcmp(pointer,d->capture[slot].data,4)) rc=-ENODATA;
    return rc;
}
static int session_output(struct experiment *d,unsigned int length)
{
    unsigned int pass,off;
    int rc;
    for(pass=0;pass<2;pass++) for(off=0;off<length;off+=MAX_READ) {
        u16 count=min_t(u32,MAX_READ,length-off);
        rc=issue(d,0x20,count,off,pass?0x5a:0xa5,ARRAY_SIZE(d->capture));
        if(rc) return rc;
        memcpy(d->stage[6+pass].data+off,d->dma_buf,count);
    }
    if(memcmp(d->stage[6].data,d->stage[7].data,length) ||
       !bio_response_valid(d->stage[2].data,d->stage[6].data,length))
        return -ENODATA;
    record(d,"VERIFIED buffer response sequence=%u status=%u bytes=%u; paired reads and immutable guards\n",
           bio_word(d->stage[6].data+BIO_OFFSET+28),
           bio_word(d->stage[6].data+BIO_OFFSET+20),
           bio_word(d->stage[6].data+BIO_OFFSET+24));
    return 0;
}
/* Persistent BIO1 session. Same transport and pinned runner as loadrun.
 * Paired payload/code checks on every STEP; full allocation every 32 STEP
 * calls and on CLOSE. Only the BIO block is uploaded after OPEN. Never retries user code. */
#define MU_READ(off) readl(d->bar+(off))
#define MU_WRITE(off,v) writel((v),d->bar+(off))
/* Host-only final ack, AFTER validated target STOP and message restoration.
 * The owned marker prevents clearing a pre-existing, unowned pending bit. */
static int mu_cleanup(struct experiment*d,unsigned int owned,unsigned int used){
 if(!owned)return used?-ENODATA:0;
 if(MU_READ(0x14)||MU_READ(0x1c)||(MU_READ(0x24)&2)||
    MU_READ(0x28)!=0x1fbu||MU_READ(0x34)!=0xffu)return -ENODATA;
 MU_WRITE(0x30,2);
 return (MU_READ(0x30)&2)?-ENODATA:0;
}

#undef MU_READ
#undef MU_WRITE

static int session_close(struct experiment *d)
{
    int rc=0, step, audit_rc=0;
    if(d->stop_started&&!d->stop_clean)return -EBUSY;
    if(d->pending || d->runner_uncertain) return -EBUSY;
    if(d->output_valid) {
        audit_rc=session_output(d,IMAGE_WINDOW);
        d->output_valid=false;
        if(d->pending) return audit_rc;
    }
    if(d->exec_dirty) {
        rc=load_table(d,d->capture[22].data,43);
        if(!rc) rc=load_expect(d,0x017e);
        if(rc) return rc;
        rc=load_code(d,d->capture[24].data,EXEC_RAM_OFFSET,EXEC_RAM_SIZE,45,46);
        if(!rc && memcmp(d->capture[24].data,d->capture[46].data,EXEC_REGION_SIZE)) rc=-ENODATA;
        if(rc) return rc;
        rc=load_code(d,d->capture[26].data,EXEC_FLASH_OFFSET,EXEC_FLASH_SIZE,48,49);
        if(!rc && memcmp(d->capture[26].data,d->capture[49].data,EXEC_REGION_SIZE)) rc=-ENODATA;
        if(rc) return rc;
        rc=exec_upload(d,d->capture[18].data,16,LOAD_RESULT_OFFSET,52);
        if(!rc) rc=read_pair(d,LOAD_RESULT_ADDRESS,16,52);
        if(!rc && memcmp(d->capture[18].data,d->capture[52].data,16)) rc=-ENODATA;
        if(rc) return rc;
        d->exec_dirty=false;
    }
    if(d->stage_dirty) {
        rc=load_chunks(d,d->stage[0].data);
        if(rc) return rc;
        rc=stage_read_pair(d,4,stage_candidate_sha256,"session-restored");
        if(!rc && memcmp(d->stage[0].data,d->stage[4].data,IMAGE_WINDOW)) rc=-ENODATA;
        if(rc) return rc;
        d->stage_dirty=false;
    }
    step=issue(d,0x1c,0,0,0x5a,3);
    if(!step && !sp_profile(d->capture[3].data)) step=-ENODATA;
    if(!step) step=audit_rc;
    d->exec_armed=false;d->load_armed=false;d->ready=false;
    record(d,"SESSION CLOSE rc=%d pending=%u exec-dirty=%u stage-dirty=%u\n",
           step,d->pending,d->exec_dirty,d->stage_dirty);
    return step;
}
static int session_open(struct experiment *d)
{
    u8 expected[32];u32 word;int rc;
    if(!d->runtime_verified) return -EPERM;
    { static const u8 allowed[32]={234,165,247,20,31,54,211,220,69,2,70,49,14,216,26,252,237,9,249,143,10,82,44,133,171,117,191,0,118,91,87,164};
      rc=load_digest(d->payload->data,d->payload->size,expected);
      if(rc||memcmp(expected,allowed,32))return -EPERM; }
    rc=stage_read_pair(d,0,stage_candidate_sha256,"session-original");
    if(rc) return rc;
    d->exec_armed=true;d->load_armed=true;
    rc=read_pair(d,EXEC_TABLE_ADDRESS,4,22);if(rc) return rc;
    if(sp_word(d->capture[22].data)!=0xfefe001cu) return -ENODATA;
    rc=read_pair(d,EXEC_RAM_ADDRESS,EXEC_REGION_SIZE,24);if(rc) return rc;
    rc=read_pair(d,EXEC_FLASH_ADDRESS,EXEC_REGION_SIZE,26);if(rc) return rc;
    rc=read_pair(d,LOAD_RESULT_ADDRESS,16,18);if(rc) return rc;
    memcpy(d->runner_code,exec_flash_code,EXEC_FLASH_SIZE);
    word=cpu_to_le32(payload_argument);memcpy(d->runner_code+16,&word,4);
    word=cpu_to_le32(STAGING_BASE+entry_offset);memcpy(d->runner_code+24,&word,4);
    memcpy(d->stage[4].data,d->stage[0].data,IMAGE_WINDOW);
    memcpy(d->stage[4].data,d->payload->data,d->payload->size);
    rc=load_digest(d->stage[4].data,IMAGE_WINDOW,expected);if(rc) return rc;
    d->stage_dirty=true;
    rc=load_chunks(d,d->payload->data);if(rc) return rc;
    rc=stage_read_pair(d,2,expected,"session-uploaded");if(rc) return rc;
    d->exec_dirty=true;
    rc=load_code(d,exec_ram_code,EXEC_RAM_OFFSET,EXEC_RAM_SIZE,28,29);if(rc) return rc;
    rc=load_code(d,d->runner_code,EXEC_FLASH_OFFSET,EXEC_FLASH_SIZE,35,36);if(rc) return rc;
    d->steps=0;d->output_valid=false;
    d->ready=true;
    record(d,"SESSION OPEN ready; original saved; no user callback armed\n");
    return 0;
}
static int session_step(struct experiment *d,const u8 *request)
{
    static const u8 sentinel[16]={0xde,0xad,0xbe,0xef};
    int rc;u64 start=ktime_get_ns();
    if(!d->ready || d->pending || d->runner_uncertain) return -EPERM;
    if(!bio_request_valid(request) || bio_word(request+8)<=d->sequence) return -EINVAL;
    if(d->steps || bio_word(request+12)!=12 || bio_word(request+BIO_INPUT)!=0x31505453u)return -EINVAL;
    d->stop_epoch=bio_word(request+BIO_INPUT+4);d->stop_delay_ms=bio_word(request+BIO_INPUT+8);
    if(!d->stop_epoch||d->stop_epoch>65535||d->stop_delay_ms<1||d->stop_delay_ms>5)return -EINVAL;
    /* Consume sequence before submission: a failed request is never replayed. */
    d->sequence=bio_word(request+8);
    memcpy(d->stage[2].data+BIO_OFFSET,request,BIO_SIZE);
    d->upload_data=request;
    rc=issue(d,0x21,BIO_SIZE,BIO_OFFSET,0xa5,ARRAY_SIZE(d->capture));
    d->upload_data=NULL;if(rc) return rc;
    /* First-entry cache handshake. Subsequent calls follow the runner's
     * self-disarm + dcctl invalidation; no intervening 6F dispatch reloads the
     * table. The unchanged runner invalidates I/D caches again on entry. */
    if(!d->steps) {
        rc=load_table(d,exec_ram_pointer,32);if(rc) return rc;
        rc=load_expect(d,0x017d);if(rc) return rc;
    }
    rc=exec_upload(d,sentinel,16,LOAD_RESULT_OFFSET,20);if(rc) return rc;
    d->runner_uncertain=true; /* before the first possible arm write */
    rc=load_table(d,exec_flash_pointer,39);if(rc) return rc;
    d->exec_expected_status=0x017f;
    rc=issue(d,0x6f,0,0,0x5a,41);if(rc) return rc;
    rc=read_pair(d,EXEC_TABLE_ADDRESS,4,43);if(rc) return rc;
    if(sp_word(d->capture[43].data)!=0xfefe001cu) return -ENODATA;
    d->runner_uncertain=false;
    rc=read_pair(d,LOAD_RESULT_ADDRESS,16,20);if(rc) return rc;
    if(sp_word(d->capture[20].data+4)!=0x52554e31u || sp_word(d->capture[20].data)) return -ENODATA;
    d->steps++;
    d->output_length=(d->steps%32)?BIO_IMAGE_SIZE:IMAGE_WINDOW;
    rc=session_output(d,d->output_length);if(rc) return rc;
    if(bio_word(d->stage[6].data+BIO_OFFSET+24)!=1024 ||
       bio_word(d->stage[6].data+BIO_OFFSET+BIO_OUTPUT+254*4)!=0x4d554f4bu)return -ENODATA;
    {unsigned int *w,i;int valid;
     w=kmalloc(1024,GFP_KERNEL);if(!w)return -ENOMEM;
     for(i=0;i<256;i++)w[i]=bio_word(d->stage[6].data+BIO_OFFSET+BIO_OUTPUT+i*4);
     valid=ownirq_report_valid(w,d->stop_epoch,d->stop_delay_ms);kfree(w);
     if(!valid){record(d,"OWNIRQ resource proof rejected after callback completion; retain resources\n");return -ENODATA;}
    }
    record(d,"OWNIRQ verified resource ownership, suspended workers, timer restored and no external leases\n");
    rc=mu_cleanup(d,1,1);if(rc)return rc;
    record(d,"STOP1 callback returned; MU words/masks restored, host OISR acknowledged\n");
    d->stop_clean=true;d->output_valid=true;
    record(d,"SESSION STEP sequence=%u elapsed_ns=%llu audit_bytes=%u; paired immutable bytes valid; PING dispatch\n",
           d->sequence,(unsigned long long)(ktime_get_ns()-start),d->output_length);
    return 0;
}
/* Probe performs read-only preflight. OPEN does the borrowing. */
static int run_stage(struct experiment *d) { (void)d;return 0; }
