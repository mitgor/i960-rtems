/home/mit/i960-rtems-web-20261011/ownership-module-wire44/dac960rtems.o
