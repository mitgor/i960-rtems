/home/mit/i960-rtems-web-20261011/residentnet-module-reclaim-release/dac960auto.o
