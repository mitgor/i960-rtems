/home/mit/i960-rtems-web-20261011/residentnet-module-reclaim/dac960auto.o
