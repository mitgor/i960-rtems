/home/mit/i960-rtems-web-20261011/residentnet-module-reclaim-final/dac960auto.o
