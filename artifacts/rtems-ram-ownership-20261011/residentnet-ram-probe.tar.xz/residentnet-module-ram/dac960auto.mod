/home/mit/i960-rtems-web-20261011/residentnet-module-ram/dac960auto.o
