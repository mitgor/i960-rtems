/home/mit/i960-rtems-web-20261011/residentnet-module-ram2/dac960auto.o
