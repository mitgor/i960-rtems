/home/mit/i960-resident-upload-20261012/residentnet-module-final/dac960auto.o
