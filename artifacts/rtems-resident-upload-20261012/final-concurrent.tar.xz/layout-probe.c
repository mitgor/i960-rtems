#include "project/loader/segmented/image.h"
unsigned int manifest_size(void){return sizeof(struct manifest);}
unsigned int segment_size(void){return sizeof(struct segment);}
