	.file	"layout-probe.c"
	.text
	.align 4
	.globl _manifest_size
	#  Function 'manifest_size'
	#  Registers used: g0 g1 fp 
	.globl	manifest_size.lf
	.leafproc	_manifest_size,manifest_size.lf
_manifest_size:
	lda    Li960R1,g14
manifest_size.lf:
	mov    g14,g1
	mov    0,g14
	ldconst	272,g0
Li960R1:	ret
	.align 4
	.globl _segment_size
	#  Function 'segment_size'
	#  Registers used: g0 g1 fp 
	.globl	segment_size.lf
	.leafproc	_segment_size,segment_size.lf
_segment_size:
	lda    Li960R2,g14
segment_size.lf:
	mov    g14,g1
	mov    0,g14
	addo	31,1,g0	# ldconst 32,g0
Li960R2:	ret
