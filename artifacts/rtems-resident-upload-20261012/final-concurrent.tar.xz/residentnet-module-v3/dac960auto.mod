/home/mit/i960-resident-upload-20261012/residentnet-module-v3/dac960auto.o
