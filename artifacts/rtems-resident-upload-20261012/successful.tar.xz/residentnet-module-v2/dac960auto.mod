/home/mit/i960-resident-upload-20261012/residentnet-module-v2/dac960auto.o
