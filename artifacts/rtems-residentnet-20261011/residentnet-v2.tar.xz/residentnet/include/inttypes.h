/*
 * inttypes.h
 *
 * ISO C99 Format conversion of integer types.
 *
 *  $Id: inttypes.h,v 1.1 2002/04/16 13:23:40 joel Exp $
 */

#ifndef __INTTYPES_H
#define __INTTYPES_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

#ifdef __cplusplus
}
#endif

#endif
