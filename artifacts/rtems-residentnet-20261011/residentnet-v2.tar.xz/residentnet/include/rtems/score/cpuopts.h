#define RTEMS_INLINE 1
#define USE_INLINES 1
#define RTEMS_CPU "i960"
#define RTEMS_CPU_MODEL "rp"
