/* 
 * rtems/stdint.h
 *
 * ISO C99 integer types
 *
 * $Id: stdint.h,v 1.1 2003/05/27 16:17:31 ralf Exp $
 */

#ifndef __rtems_stdint_h
#define __rtems_stdint_h

#ifdef __cplusplus
extern "C" {
#endif

#include <rtems/score/types.h>

/*
 * map RTEMS internal types onto C99 types 
 */
#include <machine/types.h>

typedef unsigned8      uint8_t;
typedef unsigned16     uint16_t;
typedef unsigned32     uint32_t;
typedef unsigned64     uint64_t;

#ifdef __cplusplus
}
#endif

#endif
