/* 
 * stdint.h
 *
 * ISO C99 integer types
 *
 * $Id: stdint.h,v 1.1.2.1 2003/05/27 16:32:03 ralf Exp $
 */

#ifndef __STDINT_H
#define __STDINT_H

#ifdef __cplusplus
extern "C" {
#endif

#include <rtems/stdint.h>

#ifdef __cplusplus
}
#endif

#endif
