/home/mit/i960-rtems-web-20261011/residentnet-module-v4/dac960auto.o
