/* Reads only firmware-evidenced addresses. Distinguish bus-data echo from a
 * register value; this is never an idle/completion or RAM-ownership predicate. */
static volatile unsigned int probe_seed __attribute__((aligned(16)));
static unsigned int cache_probe_read(unsigned int address,unsigned int seed,unsigned int half){
 unsigned int result,primed;probe_seed=seed;
 if(half)__asm__ volatile("ld (%2),%1;ldos (%3),%0":"=&r"(result),"=&r"(primed):"r"(&probe_seed),"r"(address):"memory");
 else __asm__ volatile("ld (%2),%1;ld (%3),%0":"=&r"(result),"=&r"(primed):"r"(&probe_seed),"r"(address):"memory");
 return result;
}
static void cache_probe(unsigned int*w){unsigned int i,cache_status,scratch;const unsigned int addresses[3]={0x40800000,0x40800008,0x4080000a};
 __asm__ volatile("dcctl 4,0,%0":"=r"(cache_status)::"memory");
 __asm__ volatile("dcctl 0,0,%0":"=r"(scratch)::"memory");
 w[0]=0x31484343;
 for(i=0;i<3;i++){w[1+i*2]=cache_probe_read(addresses[i],0xa5a5a5a5,i!=0);w[2+i*2]=cache_probe_read(addresses[i],0x5a5a5a5a,i!=0);}
 w[7]=*(volatile unsigned int*)0x1700; /* NMISR, read only */
 w[8]=*(volatile unsigned int*)0x1288; /* ATU direct-address decode control */
 w[9]=cache_status; /* observed before temporary D-cache disable */
 __asm__ volatile("dcctl 2,0,%0":"=r"(scratch)::"memory");
 if(cache_status&1)__asm__ volatile("dcctl 1,0,%0":"=r"(scratch)::"memory");
}

/* Fixed read-only decode pages. No host-selected address or register writes. */
static void cache_decode_probe(unsigned int*w,unsigned int page){
 static const unsigned int addresses[3][8]={
  {0xff008600,0xff008608,0xff008610,0xff008618,0xff008630,0xff008638,0xff0086fc,0x1288},
  {0x1500,0x1504,0x1508,0x150c,0x1510,0x1514,0x1518,0x1700},
  {0x151c,0x1520,0x1524,0x1528,0x152c,0x1530,0x40800000,0x40800008}};
 unsigned int i,status,scratch;
 if(!page||page>4){cache_probe(w);return;}
 __asm__ volatile("dcctl 4,0,%0":"=r"(status)::"memory");
 __asm__ volatile("dcctl 0,0,%0":"=r"(scratch)::"memory");
 w[0]=0x32484343;w[1]=page;
 if(page<=3)for(i=0;i<8;i++)w[i+2]=cache_probe_read(addresses[page-1][i],0x5a5a5a5a,0);
 else {
  w[2]=cache_probe_read((unsigned int)&probe_seed,0xa5a5a5a5,0);
  w[3]=cache_probe_read((unsigned int)&probe_seed,0x5a5a5a5a,0);
  w[4]=cache_probe_read((unsigned int)&probe_seed,0xa5a5a5a5,1);
  w[5]=cache_probe_read((unsigned int)&probe_seed,0x5a5a5a5a,1);
  w[6]=cache_probe_read(0x1288,0xa5a5a5a5,0);
  w[7]=cache_probe_read(0x1288,0x5a5a5a5a,0);w[8]=status;w[9]=*(volatile unsigned int*)0x1700;
 }
 __asm__ volatile("dcctl 2,0,%0":"=r"(scratch)::"memory");
 if(status&1)__asm__ volatile("dcctl 1,0,%0":"=r"(scratch)::"memory");
}
