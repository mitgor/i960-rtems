/home/mit/i960-rtems-web-20261011/residentnet-module-decode/dac960auto.o
