/home/mit/i960-rtems-web-20261011/residentnet-module-decode2/dac960auto.o
