# Cache-path qualification and resident networking — 2026-10-11

This follow-up distinguishes the card's selected internal-controller path from
external-cache code in the same firmware. It expands network storage **inside the
existing grant**, not arbitrary DRAM ownership. The cooperative net/autonet and
stock-firmware profiles remain supported; exclusive sessions retain resources
until reboot. No flash changes, cache commands or SCSI operations were made.

## Decode findings

The positive-control probe reads known RAM as `a5a5a5a5`, `5a5a5a5a`, `a5a5`,
`5a5a`, while two reads of ATUCR agree at `26`. With CPU D-cache temporarily
disabled, the suspect 32-bit cache reads still return `40800000` and `40800008`.
They cannot be used as hardware completion status.

The i960 registers are coherent with the internal-controller boot path:

| Register | Observed | Meaning / limit |
|---|---|---|
| PMCON4_5 | `00800000` | Region entry requests 32-bit width, **but** BCON must also be checked. |
| PMCON14_15 / BCON | `0` / `1` | BCON bit 2 clear: region entries are not valid; default width applies. |
| ATUCR | `26` | Direct-address mode bit 8 clear. |
| MBCR / bank bases | `007100f1`, `fe000000`, `e0000000` | Matches the boot's ROM/peripheral setup. Not an exhaustive external chip-select map. |
| DBCR / DRAM base | `b4f` / `c0000000` | Internal DRAM enabled; this is also the firmware sizing routine's probe configuration. |
| NMISR | `0` | No recorded NMI indication; not proof of a valid external register read. |

DBCR's arrangement field is 9, with 64 MiB bank/leaf encoding. **Do not infer
installed capacity from that**: `c004fc40` deliberately installs `b4f` before
alias tests at 4, 16 and 64 MiB offsets. It returns the detected size. This batch
does not repeat the destructive startup sizing test.

The decisive new evidence is in the bootstrap, not the unpacked program alone:

- Flash `fefcb46c..fefcb49c` reads byte `e0400000`, masks with 31 and selects
  internal setup for value 6. A second entry repeats the same selection.
- Flash `fefcc1f0` installs CPU XOR at runtime `c000d540` in dispatch offset `c0`,
  DRAM sizing `c004fc40` at `168`, and internal timer `c0050430` at `164`.
- Flash `fefcc310` instead installs `c004e940` or `c004ea80`, the previously
  recovered external-cache command/completion routines. It installs different
  status/mask hooks and external sizing `c004f9d0`.
- The live dispatch pointer is `c0110780`; offsets `170..18c` match the internal
  setup exactly. Several are the no-op `c004c3b0`, not external status/ACK functions.
- The internal XOR implementation is a CPU load/XOR/store loop ending in return.
  Its operation completion is synchronous CPU return, not the external bit-0
  wait. This does not drain SCSI or establish ownership of every firmware range.

Bootstrap flash addresses in the disassembly are not their relocated execution
addresses: copied raw offsets `1000..6fff` run at offset + `c0009000`.
`decode_audit.py` checks 48,750 bootstrap rows against bytes; `audit.py` checks
73,608 unpacked rows. The corresponding excerpts are archived with the evidence.
The final board-selector and primary dispatch capture is recorded in the artifact
README; a matching subset alone is not an exhaustive reachability proof.

## RAM and networking changes

The resident transmit queue grows from 8 to 32 packets: 49,152 bytes of packet
storage, plus length metadata. The additional 36,912 bytes come from the existing
mutable allocation. The linked image leaves 61,232 bytes before the upper guard.
The RAM audit now checks the entire queue object extent as well as symbol bounds.
No outside range is admitted; `ram_reclaim()` continues to return zero.

The resident-only tick ceiling is 60,000 (nominal ten minutes); the exclusive
non-network profile retains its 6,000 ceiling. The tested deadline is **12,000**,
not the maximum. A successful run performed three rounds of UDP (including MTU
limits), TCP echo and HTTP over each IP family, with a deliberately dropped TCP
data packet in each family. It then stayed resident without host packet traffic
until its deadline, parked at exactly 12,000 ticks, drained both IRQ contexts,
rejected post-park packets and retained the module. There was one firmware ARM
callback, with no firmware submission after takeover.

The first longer run found a real relay defect: `EAGAIN` from an RX-begin rejection
was fatal to the harness, losing its pending TUN packet. The correction keeps
that exact packet pending, services TX and retries only a definite `EAGAIN`.
Timeout, protocol error and other uncertain outcomes still terminate the session.
The failed run and its retained-close evidence are preserved. The successful
rerun did not happen to encounter busy RX; native tests force repeated busy
responses and verify packet preservation and no uncertain-operation retry.

`test_queue.py` exercises the actual queue functions at both 8 and 32 slots:
full rejection, insufficient output capacity, repeated wrap, ordered drain and
oversized input. It runs with ASan/UBSan. `test_pump.py` forces three busy replies
and five non-retryable errors. Existing packet/host/native tests remain applicable.

## Remaining work

1. Use the qualified internal CPU path to revise the whole-engine ownership
   checklist; do not wait on unrelated external-cache status. Check the primary
   dispatch on every future takeover before relying on this board-specific fact.
2. Enumerate firmware allocations, saved interrupt continuations and SCSI-local
   DMA/bus ownership before granting a new physical RAM interval. Firmware size
   reports and address decoding are evidence, not allocation permission.
3. Qualify timer accuracy under sustained load, RX-busy retry on the card, queue
   saturation on the card, concurrent connections and the full ten-minute limit.
4. Establish dependable reboot/reset from retained exclusive mode. Keep production
   on autonet until resident recovery and longer service operation are qualified.
5. Host-RAM DMA and direct-NIC operation still require separate descriptor,
   coherency, PCI-master and cancellation ownership contracts.
