/home/mit/i960-rtems-web-20261011/residentnet-module-scsi-final/dac960auto.o
