/home/mit/i960-rtems-web-20261011/residentnet-module-scsi-reset/dac960auto.o
