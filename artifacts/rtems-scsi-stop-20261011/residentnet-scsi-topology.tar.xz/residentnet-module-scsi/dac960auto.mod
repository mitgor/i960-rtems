/home/mit/i960-rtems-web-20261011/residentnet-module-scsi/dac960auto.o
