/home/mit/i960-rtems-web-20261011/residentnet-module-shared-endurance/dac960auto.o
