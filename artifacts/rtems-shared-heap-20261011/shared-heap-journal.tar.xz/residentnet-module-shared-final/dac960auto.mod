/home/mit/i960-rtems-web-20261011/residentnet-module-shared-final/dac960auto.o
