#define WORKER_ITERATIONS 1000
#define I960_GENERAL_HEAP 1
#define I960_HEAP_TEST 0
#define HEAP_NATIVE 1
#include "general_heap.c"
unsigned int _ISR_Nest_level;
void*memset(void*p,int c,size_t n){unsigned char*q=p;while(n--)*q++=c;return p;}
void*memcpy(void*p,const void*q,size_t n){unsigned char*d=p;const unsigned char*s=q;while(n--)*d++=*s++;return p;}
static void quit(unsigned int code){__asm__ volatile("int $0x80"::"a"(1),"b"(code):"memory");for(;;){}}
#define CHECK(x) do{if(!(x))quit(__LINE__);}while(0)
void _start(void){unsigned int i,t,old;unsigned char*p;void*saved;void*slots[64];
 if(__builtin_setjmp(native_jump))quit(128+heap_error);
 CHECK(sizeof(void*)==4);CHECK(!resident_malloc(1));CHECK(!resident_heap_init());CHECK(resident_heap_valid()&&selftest);
 p=resident_malloc(RESIDENT_HEAP_BYTES-64);CHECK(p&&resident_heap_valid());
 CHECK(!resident_malloc(1));CHECK(!resident_free(p)&&resident_heap_valid());
 for(i=0;i<64;i++){slots[i]=resident_malloc(1);CHECK(slots[i]&&!((unsigned int)slots[i]&15));}
 CHECK(!resident_malloc(1));CHECK(!resident_realloc(slots[0],2));
 for(i=0;i<64;i++)CHECK(!resident_free(slots[i]));
 p=resident_realloc(0,100);CHECK(p);memset(p,0x71,100);
 p=resident_realloc(p,20);CHECK(p);for(i=0;i<20;i++)CHECK(p[i]==0x71);
 CHECK(!resident_realloc(p,0)&&!resident_free(0));
 for(t=1;t<=WORKER_ITERATIONS;t++){native_actor=0;resident_heap_step(0,t);native_actor=1;resident_heap_step(1,t);}
 native_actor=0;resident_heap_drain(0);native_actor=1;resident_heap_drain(1);CHECK(!live_bytes&&allocations==frees&&resident_heap_valid());
#ifdef I960_HEAP_SHARED
 {unsigned int h,h2,prior=shared_generation;
  native_actor=0;CHECK(!resident_shared_resume(0));native_actor=1;CHECK(!resident_shared_resume(1));
  native_actor=0;h=resident_shared_new(0,100);CHECK(h&&resident_shared_acquire(h,1));
  native_actor=1;CHECK(!resident_shared_acquire(h,1));p=resident_shared_pin(h,1);CHECK(p);memset(p,0x29,100);
  CHECK(!resident_shared_cancel(0)&&resident_shared_ack(h,0));native_actor=0;CHECK(!resident_shared_ack(h,0));
  CHECK(!resident_shared_new(0,1));CHECK(!resident_shared_resume(0));CHECK(resident_shared_acquire(h,0));
  native_actor=1;CHECK(!resident_shared_cancel(1));old=frees;
  for(i=0;i<1000;i++)CHECK(resident_shared_ack(h,1)==2&&frees==old&&p[i%100]==0x29&&resident_heap_valid());
  CHECK(!resident_shared_unpin(h,1)&&!resident_shared_ack(h,1));CHECK(resident_shared_ack(h,1));CHECK(!resident_shared_resume(1));
  native_actor=0;h2=resident_shared_new(0,100);CHECK(h2!=h&&!resident_shared_pin(h,0));
  CHECK(!resident_shared_cancel(0)&&!resident_shared_ack(h2,0)&&!resident_shared_resume(0));
  h=resident_shared_new(0,100);CHECK(h);old=frees;shared[h&7].pins=2;
  if(!__builtin_setjmp(native_jump)){resident_free(shared[h&7].p);quit(205);}
  CHECK(heap_error==11&&frees==old);shared[h&7].pins=0;heap_error=0;native_mask=0;
  CHECK(!resident_shared_cancel(0)&&!resident_shared_ack(h,0)&&!resident_shared_resume(0));
  {unsigned int sum[2]={0xfffffff0u,1};add_time(sum,32);CHECK(sum[0]==16&&sum[1]==2);}
  prior=shared_generation;shared_generation=0x1ffffffe;
  h=resident_shared_new(0,1);CHECK(h>>3==0x1fffffff);CHECK(!resident_shared_cancel(0)&&!resident_shared_ack(h,0)&&!resident_shared_resume(0));
  CHECK(!resident_shared_new(0,1));shared_generation=prior;
  CHECK(!resident_shared_cancel(0)&&!resident_shared_cancel(1));
 }
#endif
#ifdef I960_HEAP_SHARED
 {unsigned int state=17,h,a,action,slot;
  for(t=0;t<5000;t++){
   state=state*1664525u+1013904223u;a=state&1;native_actor=a;action=(state>>5)%7;slot=(state>>12)&7;
   h=shared[slot].p?(shared[slot].generation<<3)|slot:0;
   if(action==0)resident_shared_new(a,1+(state%512));
   else if(action==1)resident_shared_acquire(h,a);
   else if(action==2)resident_shared_pin(h,a);
   else if(action==3)resident_shared_unpin(h,a);
   else if(action==4)resident_shared_cancel(a);
   else if(action==5)resident_shared_ack(h,a);
   else resident_shared_resume(a);
   CHECK(resident_heap_valid());
   for(i=0;i<8;i++)if(shared[i].p)CHECK(shared[i].refs&&!(shared[i].pins&~shared[i].refs));
  }
  resident_shared_cancel(0);resident_shared_cancel(1);
  for(a=0;a<2;a++){native_actor=a;for(i=0;i<8;i++)if(shared[i].p){
   h=(shared[i].generation<<3)|i;if(shared[i].pins&(1u<<a))CHECK(!resident_shared_unpin(h,a));
   if(shared[i].refs&(1u<<a))CHECK(!resident_shared_ack(h,a));
  }}
  CHECK(shared_created==shared_retired&&!live_bytes&&allocations==frees);
 }
#endif
 p=resident_malloc(100);CHECK(p);blocks[find_block(p)].busy=1;old=frees;
 CHECK(resident_free(p)&&!resident_realloc(p,200)&&frees==old);blocks[find_block(p)].busy=0;CHECK(!resident_free(p));
 _ISR_Nest_level=1;CHECK(!resident_malloc(64)&&native_mask==0);_ISR_Nest_level=0;
 p=resident_malloc(100);CHECK(p);old=frees;
 for(i=0;i<32;i++){
  unsigned char*q=i<16?p-16+i:p+100+i-16;*q^=1;
  if(!__builtin_setjmp(native_jump)){resident_malloc(1);quit(200);}
  CHECK(heap_error==3&&frees==old);*q^=1;heap_error=0;native_mask=0;
 }
 for(i=0;i<32;i++){
  unsigned int*q=(unsigned int*)(p-20);*q^=1u<<i;
  if(!__builtin_setjmp(native_jump)){resident_free(p);quit(203);}
  CHECK(heap_error==2&&frees==old);*q^=1u<<i;heap_error=0;native_mask=0;
 }
 saved=app_heap.first;
 for(i=0;i<32;i++){
  app_heap.first=(void*)((unsigned int)saved^(1u<<i));
  if(!__builtin_setjmp(native_jump)){resident_malloc(1);quit(201);}
  CHECK(heap_error==2&&frees==old);app_heap.first=saved;heap_error=0;native_mask=0;
 }
 native_admit=0;
 if(!__builtin_setjmp(native_jump)){resident_malloc(1);quit(202);}
 CHECK(heap_error==1&&frees==old);native_admit=1;heap_error=0;native_mask=0;
 CHECK(!resident_free(p)&&!live_bytes&&allocations==frees&&resident_heap_valid());
 slots[0]=resident_malloc(100);slots[1]=resident_malloc(100);slots[2]=resident_malloc(100);
 CHECK(slots[0]&&slots[1]&&slots[2]);CHECK(!resident_free(slots[0])&&!resident_free(slots[2]));
 saved=app_heap.first->next;app_heap.first->next=0;old=frees;
 if(!__builtin_setjmp(native_jump)){resident_free(slots[1]);quit(204);}
 CHECK(heap_error==2&&frees==old);app_heap.first->next=saved;heap_error=0;native_mask=0;
 CHECK(!resident_free(slots[1])&&!live_bytes&&allocations==frees&&resident_heap_valid());
#ifdef I960_HEAP_SHARED
 CHECK(shared_cycles>50&&shared_checks>50&&shared_created==shared_retired&&shared_deferred>50);
 CHECK(shared_cancelled==3&&shared_tested);
 {unsigned int report[64];resident_heap_diagnostics(report);
  __asm__ volatile("int $0x80"::"a"(4),"b"(1),"c"(report),"d"(sizeof(report)):"memory");}
#endif
 quit(0);
}
