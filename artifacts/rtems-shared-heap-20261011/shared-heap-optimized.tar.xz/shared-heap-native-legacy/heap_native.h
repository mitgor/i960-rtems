static unsigned char native_arena[RESIDENT_HEAP_BYTES] __attribute__((aligned(16)));
#define HEAP_BASE ((unsigned int)native_arena)
static unsigned int native_admit=1,native_mask,native_actor;
static int native_jump[5];
#define HEAP_ABORT() __builtin_longjmp(native_jump,1)
static unsigned int exclusive_extra_valid(void){return native_admit;}
static unsigned int exclusive_extra_guard_mask(void){return !native_admit;}
static unsigned int heap_raw_lock(void){unsigned int old=native_mask;native_mask=31;return old;}
static void heap_raw_unlock(unsigned int old){native_mask=old;}
