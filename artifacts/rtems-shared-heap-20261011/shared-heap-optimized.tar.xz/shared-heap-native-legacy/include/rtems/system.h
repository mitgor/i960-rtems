#ifndef TEST_SYSTEM_H
#define TEST_SYSTEM_H
typedef unsigned int unsigned32;typedef int boolean;typedef unsigned int size_t;
#define TRUE 1
#define FALSE 0
#define NULL ((void*)0)
#define RTEMS_INLINE_ROUTINE static inline
#define CPU_HEAP_ALIGNMENT 16
#define CPU_ALIGNMENT 16
#endif
