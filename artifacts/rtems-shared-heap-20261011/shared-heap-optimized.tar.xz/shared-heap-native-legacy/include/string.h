#include <rtems/system.h>
void*memset(void*,int,size_t);void*memcpy(void*,const void*,size_t);
