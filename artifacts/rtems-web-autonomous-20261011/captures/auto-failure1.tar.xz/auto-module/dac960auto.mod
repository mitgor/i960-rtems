/home/mit/i960-rtems-web-20261011/auto-module/dac960auto.o
