/home/mit/i960-rtems-web-20261011/auto-module2/dac960auto.o
