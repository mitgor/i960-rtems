/home/mit/i960-rtems-web-20261011/auto-module3/dac960auto.o
