/home/mit/i960-rtems-web-20261011/autonet-module4/dac960auto.o
