/home/mit/i960-rtems-web-20261011/autonet-module5/dac960auto.o
