/home/mit/i960-rtems-web-20261011/autonet-module-final/dac960auto.o
