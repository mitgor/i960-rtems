savedcmd_/home/mit/i960-segmented-20261012/module/modules.order := {   echo /home/mit/i960-segmented-20261012/module/dac960loadrun.o; :; } > /home/mit/i960-segmented-20261012/module/modules.order
