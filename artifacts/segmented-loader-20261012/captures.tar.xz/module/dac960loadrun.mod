/home/mit/i960-segmented-20261012/module/dac960loadrun.o
