#!/usr/bin/env python3
"""Replay read-only profile reports and cache telemetry; requires normal full verifiers too."""
import argparse,json,struct
from pathlib import Path
NAMES=('read_total','frame_barrier','allocation_and_loans','staging_init','release_and_returns','guards','dma_start_to_completion','transfer_total','response_wait','service_yield','staging_copy','benchmark_transfer','benchmark_hardware','benchmark_guards','empty_bracket','benchmark_verify','response_transfer')
def verify(path):
 p=Path(path);words=json.loads((p/'wad-profile.json').read_text())['words']
 assert len(words)==59 and words[:8]==[0x31525057,1,4166700,64,64,32768,0,0]
 requests=[];replies={}
 for line in (p/'upload-journal.jsonl').read_text().splitlines():
  row=json.loads(line);q=bytes.fromhex(row['request'])
  if row['op']==1:
   h=struct.unpack_from('<8I',q,32)
   if h[2]==21 and h[3]>=8:
    assert h[4:]==(0,0,0,0) and 8<=h[3]<67;requests.append((h[1],h[3]-8))
  if row['op']==2:
   b=bytes.fromhex(row['response']);h=struct.unpack_from('<16I',b,32)
   if h[0]==0x31525055 and h[3]==0:replies[h[1]]=h
 assert len(requests)==59 and [i for s,i in requests]==list(range(59))
 assert [replies[s][5] for s,i in requests]==words and all(replies[s][2]==0 for s,i in requests)
 metrics={}
 for i,name in enumerate(NAMES):
  count,lo,hi=words[8+3*i:11+3*i];assert count and 0<=lo<=0xffffffff and 0<=hi<=0xffffffff
  metrics[name]=dict(count=count,seconds=((hi<<32)|lo)/words[2])
 assert metrics['benchmark_transfer']['count']==metrics['benchmark_hardware']['count']==metrics['benchmark_verify']['count']==64
 assert metrics['benchmark_guards']['count']==128
 assert metrics['guards']['count']==2*metrics['transfer_total']['count']
 assert metrics['transfer_total']['count']==metrics['dma_start_to_completion']['count']
 assert metrics['response_transfer']['count']>=2*metrics['response_wait']['count']
 s=lambda n:metrics[n]['seconds']
 assert s('benchmark_transfer')>s('benchmark_hardware') and s('read_total')>s('transfer_total') and s('response_wait')>=s('response_transfer')
 cache=[]
 for g in range(1,101):
  b=(p/f'play-0-{g}.bin').read_bytes();w=struct.unpack_from('<16I',b,64960)
  assert w[:2]==(0x31435057,1) and w[-1]==10
  assert w[6]==w[7]==w[8] and all(t%10==0 for t in w[2:6])
  if cache:assert all(x>=y for x,y in zip(w[2:15],cache[-1][2:15]))
  cache.append(w)
 names=('runtime_read','fill_cache','miss_copy_to_doom','hit_copy_to_doom')
 def decode(w):return dict(seconds={n:w[2+i]/1000 for i,n in enumerate(names)},calls=dict(zip(names,w[6:10])),wire_bytes=w[10],copied_bytes=w[11],logical_reads=w[12],cache_hits=w[13],cache_line_misses=w[14])
 host=json.loads((p/'wad-ring-service.json').read_text())
 return dict(timer_hz_nominal=words[2],timer_is_elapsed_not_cpu=True,metrics=metrics,benchmark_bytes=64*32768,benchmark_hardware_MBps=(64*32768/1e6)/s('benchmark_hardware'),benchmark_checked_MBps=(64*32768/1e6)/s('benchmark_transfer'),response_wait_excluding_response_dma_seconds=s('response_wait')-s('response_transfer'),first_frame_cache=decode(cache[0]),final_cache=decode(cache[-1]),warm_restart_cache_ms=[cache[67][i]-cache[65][i] for i in range(2,6)],host=host)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('capture');a=p.parse_args();print(json.dumps(verify(a.capture),indent=2))
