# Pipelined WAD ring (work in progress)

Two retained coherent host slots, each 40 KiB: a 4 KiB lower guard, 64-byte
request, response and completion records, 32 KiB payload, and an upper guard.
Records contain no caller-selected address. The Linux driver registers its
private addresses once before engine startup. The same owning RTEMS task
serializes all ring and framebuffer operations on DMA1.

For a 64 KiB aligned read-ahead miss, the card publishes up to two requests
before consuming responses. The host fills both requests from its immutable WAD
snapshot. Response publication follows payload writes and a DMA write barrier.
The card validates exact generation and geometry before fetching a payload.
Completion is published only after DMA is quiescent and guards pass. Neither
party can recycle a slot before completion of its previous generation.
Generation zero and wrap are forbidden. No cyclic DMA descriptor chain is used.

STOP and bounded waits must quiesce DMA before releasing any card allocation.
An uncertain hardware completion quarantines resources until reboot. Host
mappings remain pinned for the full resident session, including STOP and errors.
Full system/RAM audits and ownership checks are mandatory. No physical acceptance
or speed improvement is claimed until archived card captures pass replay.
